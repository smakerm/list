=================================================================
 :mod:`gevent.resolver.thread` -- thread based hostname resolver
=================================================================

.. automodule:: gevent.resolver.thread
    :members:
