===========
 Changelog
===========

.. currentmodule:: gevent

1.3a2 (2018-03-06)
==================

Dependencies
------------

- Cython 0.28b1 or later is now required to build gevent from a source
  checkout (Cython is *not* required to build a source distribution
  from PyPI).

- Update c-ares to 1.14.0. See :issue:`1105`.

- gevent now **requires** the patched version of libuv it is
  distributed with. Building gevent with a non-embedded libuv, while
  not previously supported, is not possible now. See
  :issue:`1126`.


Platform Support
----------------

- Travis CI tests on Python 3.7.0b2 and PyPy 2.7 5.10.0 and PyPy 3.5
  5.10.1.

Build Changes
-------------

- Fix building from a source distribution (PyPI) without Cython
  installed.

- greenlet is now required at build time. If it is not installed
  before gevent is installed, gevent will be built twice when
  installing from source.

Enhancements
------------

- Add the ``dnspython`` resolver as a lightweight alternative to
  c-ares. It is generally faster than c-ares and is supported on PyPy.
  c-ares may be deprecated in the future. See :pr:`1088` and
  :issue:`1103`.

- Add the module :mod:`gevent.time` that can be imported instead of
  :mod:`time`, much like :mod:`gevent.socket` can be imported instead
  of :mod:`socket`. It contains ``gevent.sleep``. This aids
  monkey-patching.

- Simple subclasses of `gevent.local.local` now have the same
  (substantially improved) performance characteristics of plain
  `gevent.local.local` itself, making them 2 to 3 times faster than
  before. See :pr:`1117`. If there are any compatibility
  problems, please open issues.

Monitoring and Debugging
~~~~~~~~~~~~~~~~~~~~~~~~

- Greenlet objects now keep track of their spawning parent greenlet
  and the code location that spawned them, in addition to maintaining
  a "spawn tree local" mapping. This adds some runtime overhead in
  relative terms, but absolute numbers are still relatively small.
  Based on a proposal from PayPal and comments by Mahmoud Hashemi and
  Kurt Rose. See :issue:`755` and :pr:`1115`. As always, feedback is
  appreciated.

- Greenlet objects now have a `minimal_ident
  <gevent.Greenlet.minimal_ident>` property. It functions
  similarly to ``Thread.ident`` or ``id`` by uniquely identifying the
  greenlet object while it remains alive, and it can be reused after
  the greenlet object is dead. It is different in that it is small and
  sequential. Based on a proposal from PayPal and comments by Mahmoud
  Hashemi and Kurt Rose. See :issue:`755`. As always, feedback is
  appreciated.

- `gevent.Greenlet` objects now have a `gevent.Greenlet.name`
  attribute that is included in the default repr.

- Include the values of `gevent.local.local` objects associated with
  each greenlet in `gevent.util.format_run_info`.

- Add `gevent.util.GreenletTree` to visualize the greenlet tree. This
  is used by `gevent.util.format_run_info`.


Subprocess
~~~~~~~~~~

- Make :class:`gevnt.subprocess.Popen` accept the ``restore_signals``
  keyword argument on all versions of Python, and on Python 2 have it
  default to false. It previously defaulted to true on all versions;
  now it only defaults to true on Python 3. The standard library in
  Python 2 does not have this argument and its behaviour with regards
  to signals is undocumented, but there is code known to rely on
  signals not being restored under Python 2. Initial report and patch
  in :pr:`1063` by Florian Margaine.

- Allow :class:`gevent.subprocess.Popen` to accept the keyword
  arguments ``pass_fds`` and ``start_new_session`` under Python 2.
  They have always had the same default as Python 3, namely an empty
  tuple and false, but now are accessible to Python 2.

- Support the ``capture_output`` argument added to Python 3.7 in
  :func:`gevent.subprocess.run`.

Configuration
~~~~~~~~~~~~~

- Centralize all gevent configuration in an object at
  ``gevent.config``, allowing for gevent to be configured through code
  and not *necessarily* environment variables, and also provide a
  centralized place for documentation. See :issue:`1090`.

  - The new ``GEVENT_CORE_CFFI_ONLY`` environment variable has been
    replaced with the pre-existing ``GEVENT_LOOP`` environment
    variable. That variable may take the values ``libev-cext``,
    ``libev-cffi``, or ``libuv-cffi``, (or be a list in preference
    order, or be a dotted name; it may also be assigned to an
    object in Python code at ``gevent.config.loop``).

  - The ``GEVENTARES_SERVERS`` environment variable is deprecated in
    favor of ``GEVENT_RESOLVER_SERVERS``. See :issue:`1103`.


Bug Fixes
---------

- Fix calling ``shutdown`` on a closed socket. It was raising
  ``AttributeError``, now it once again raises the correct
  ``socket.error``. Reported in :issue:`1089` by André Cimander.

- Fix an interpreter crash that could happen if two or more ``loop``
  objects referenced the default event loop and one of them was
  destroyed and then the other one destroyed or (in the libev C
  extension implementation only) deallocated (garbage collected). See
  :issue:`1098`.

- Fix a race condition in libuv child callbacks. See :issue:`1104`.

Other Changes
-------------

- The internal, undocumented module ``gevent._threading`` has been
  simplified.

- The internal, undocumented class ``gevent._socket3._fileobject`` has
  been removed. See :issue:`1084`.

- Simplify handling of the libev default loop and the ``destroy()``
  method. The default loop, when destroyed, can again be requested and
  it will regenerate itself. The default loop is the only one that can
  receive child events.

- Make :meth:`gevent.socket.socket.sendall` up to ten times faster on
  PyPy3, through the same change that was applied in gevent 1.1b3 for PyPy2.

- Be more careful about issuing a warning about patching SSL on
  Python 2. See :issue:`1108`.

- Signal handling under PyPy with libuv is more reliable. See
  :issue:`1112`.

- The :mod:`gevent.greenlet` module is now compiled with Cython to
  offset any performance decrease due to :issue:`755`. Please open
  issues for any compatibility concerns. See :pr:`1115` and :pr:`1120`.

- On CPython, allow the pure-Python implementations of
  `gevent.Greenlet`, `gevent.local` and `gevent.lock` to be
  used when the environment variable ``PURE_PYTHON`` is set. This is
  not recommended except for debugging and testing. See :issue:`1118`.

- :meth:`gevent.select.poll.poll` now interprets a *timeout* of -1 the
  same as a *timeout* of *None* as the standard requires. Previously,
  on libuv this was interpreted the same as a *timeout* of 0. In
  addition, all *timeout* values less than zero are interpreted like
  *None* (as they always were under libev). See :issue:`1127`.

- Monkey-patching now defaults to patching ``threading.Event``.

1.3a1 (2018-01-27)
==================

Dependencies
------------

- gevent is now built and tested with Cython 0.27. This is required
  for Python 3.7 support.

- Update c-ares to 1.13.0. See :issue:`990`.


Platform Support
----------------

- Add initial support for Python 3.7a3. It has the same level of
  support as Python 3.6.

  - Using unreleased Cython 0.28 and greenlet 0.4.13; requires Python 3.7a3.

  - The ``async`` functions and classes have been renamed to
    ``async_`` due to ``async`` becoming a keyword in Python 3.7.
    Aliases are still in place for older versions. See :issue:`1047`.

- gevent is now tested on Python 3.6.4. This includes the following
  fixes and changes:

  - Errors raised from :mod:`gevent.subprocess` will have a
    ``filename`` attribute set.
  - The :class:`threading.Timer` class is now monkey-patched and can
    be joined. Previously on Python 3.4 and above, joining a ``Timer``
    would hang the process.
  - :meth:`gevent.ssl.SSLSocket.unwrap` behaves more like the standard
    library, including returning a SSLSocket and allowing certain
    timeout-related SSL errors to propagate. The added standard
    library tests ``test_ftplib.py`` now passes.
  - :class:`gevent.subprocess.Popen` accepts a "path-like object" for
    the *cwd* parameter on all platforms. Previously this only worked
    on POSIX platforms under Python 3.6. Now it also works on Windows under
    Python 3.6 (as expected) and is backported to all previous versions.

- Linux CI now tests on PyPy3 3.5-5.9.0, updated from PyPy3 3.5-5.7.1.
  See :issue:`1001`. PyPy2 has been updated to 5.9.0 from 5.7.1,
  Python 2.7 has been updated to 2.7.14 from 2.7.13, Python 3.4 is
  updated to 3.4.7 from 3.4.5, Python 3.5 is now 3.5.4 from 3.5.3, and
  Python 3.6 is now 3.6.4 from 3.6.0.

- Drop support for Python 3.3. The documentation has only claimed
  support for 3.4+ since gevent 1.2 was released, and only 3.4+ has
  been tested. This merely removes the supporting Trove classifier and
  remaining test code. See :issue:`997`.

- PyPy is now known to run on Windows using the libuv backend, with
  caveats. See the section on libuv for more information.

- Due to security concerns, official support for Python 2.7.8 and
  earlier (without a modern SSL implementation) has been dropped.
  These versions are no longer tested with gevent, but gevent can
  still be installed on them. Supporting code will be removed in the
  next major version of gevent. See :issue:`1073`.

Build Changes
-------------

- When building gevent from a source checkout (*not* a distributed
  source distribution), ``make`` is no longer required and the
  ``Makefile`` is not used. Neither is an external ``cython`` command.
  Instead, the ``cythonize`` function is used, as recommended by
  Cython. (The external commands were never required by source
  distributions.) See :issue:`1076`.

- :class:`gevent.local.local` is compiled with Cython on CPython.

- The Cython ares 'channel' class is no longer declared to be publicly
  accessible from a named C structure. Doing so caused a conflict with
  the c-ares header files.

Bug Fixes
---------

- If a single greenlet created and destroyed many
  :class:`gevent.local.local` objects without ever exiting, there
  would be a leak of the function objects intended to clean up the
  locals after the greenlet exited. Introduce a weak reference to
  avoid that. Reported in :issue:`981` by Heungsub Lee.

- pywsgi also catches and ignores by default
  :const:`errno.WSAECONNABORTED` on Windows. Initial patch in
  :pr:`999` by Jan van Valburg.

- :meth:`gevent.subprocess.Popen.communicate` returns the correct type
  of str (not bytes) in universal newline mode under Python 3, or when
  an encoding has been specified. Initial patch in :pr:`939` by
  William Grzybowski.

- :meth:`gevent.subprocess.Popen.communicate` (and in general,
  accessing ``Popen.stdout`` and ``Popen.stderr``) returns the correct
  type of str (bytes) in universal newline mode under Python 2.
  Previously it always returned unicode strings. Reported in
  :issue:`1039` by Michal Petrucha.

- :class:`gevent.fileobject.FileObjectPosix` returns native strings in
  universal newline mode on Python 2. This is consistent with what
  :class:`.FileObjectThread` does. See :issue:`1039`.

- ``socket.send()`` now catches ``EPROTOTYPE`` on macOS to handle a race
  condition during shutdown. Fixed in :pr:`1035` by Jay Oster.

- :func:`gevent.socket.create_connection` now properly cleans up open
  sockets if connecting or binding raises a :exc:`BaseException` like
  :exc:`KeyboardInterrupt`, :exc:`greenlet.GreenletExit` or
  :exc:`gevent.timeout.Timeout`. Reported in :issue:`1044` by
  kochelmonster.


Other Changes
-------------

- ``Pool.add`` now accepts ``blocking`` and ``timeout`` parameters,
  which function similarly to their counterparts in ``Semaphore``.
  See :pr:`1032` by Ron Rothman.

- Defer adjusting the stdlib's list of active threads until
  ``threading`` is monkey patched. Previously this was done when
  :mod:`gevent.threading` was imported. That module is documented to
  be used as a helper for monkey patching, so this should generally
  function the same, but some applications ignore the documentation
  and directly import that module anyway.

  A positive consequence is that ``import gevent.threading, threading;
  threading.current_thread()`` will no longer return a DummyThread
  before monkey-patching. Another positive consequence is that PyPy
  will no longer print a ``KeyError`` on exit if
  :mod:`gevent.threading` was imported *without* monkey-patching.

  See :issue:`984`.

- Specify the Requires-Python metadata for improved installation
  support in certain tools (setuptools v24.2.1 or newer is required).
  See :issue:`995`.

- Monkey-patching after the :mod:`ssl` module has been imported now
  prints a warning because this can produce ``RecursionError``.

- :class:`gevent.local.local` objects are now approximately 3.5 times faster
  getting, setting and deleting attributes on PyPy. This involved
  implementing more of the attribute protocols directly. Please open
  an issue if you have any compatibility problems. See :issue:`1020`.

- :class:`gevent.local.local` is compiled with Cython on CPython. It
  was already 5 to 6 times faster due to the work on :issue:`1020`,
  and compiling it with Cython makes it another 5 to 6 times faster,
  for a total speed up of about 35 times. It is now in the same
  ballpark as the native :class:`threading.local` class. It also uses
  one pointer less memory per object, and one pointer less memory per
  greenlet. See :pr:`1024`.

- More safely terminate subprocesses on Windows with
  :meth:`gevent.subprocess.Popen.terminate`. Reported in :issue:`1023`
  by Giacomo Debidda.

- gevent now uses cffi's "extern 'Python'" callbacks. These should be
  faster and more stable. This requires at least cffi 1.4.0. See :issue:`1049`.

- gevent now approximately tries to stick to a scheduling interval
  when running callbacks, instead of simply running a count of
  callbacks. The interval is determined by
  :func:`gevent.getswitchinterval`. On Python 3, this is the same as
  the thread switch interval. On Python 2, this defaults to 0.005s and
  can be changed with :func:`gevent.setswitchinterval`. This should
  result in more fair "scheduling" of greenlets, especially when
  ``gevent.sleep(0)`` or other busy callbacks are in use. The interval
  is checked every 50 callbacks to keep overhead low. See
  :issue:`1072`. With thanks to Arcadiy Ivanov and Antonio Cuni.

libuv
-----

- Add initial *experimental* support for using libuv as a backend
  instead of libev, controlled by setting the environment variable
  ``GEVENT_CORE_CFFI_ONLY=libuv`` before importing gevent. This
  suffers a number of limitations compared to libev, notably:

  - libuv support is not available in the manylinux wheels uploaded to
    PyPI. The manylinux specification requires glibc 2.5, while libuv
    requires glibc 2.12. Install from source to access libuv on Linux
    (e.g., pip's ``--no-binary`` option).

  - Timers (such as ``gevent.sleep`` and ``gevent.Timeout``) only
    support a resolution of 1ms (in practice, it's closer to 1.5ms).
    Attempting to use something smaller will automatically increase it
    to 1ms and issue a warning. Because libuv only supports
    millisecond resolution by rounding a higher-precision clock to an
    integer number of milliseconds, timers apparently suffer from more
    jitter.

  - Using negative timeouts may behave differently from libev.

  - libuv blocks delivery of all signals, so signals are handled using
    an (arbitrary) 0.3 second timer. This means that signal handling
    will be delayed by up to that amount, and that the longest the
    event loop can sleep in the operating system's ``poll`` call is
    that amount. Note that this is what gevent does for libev on
    Windows too.

  - libuv only supports one io watcher per file descriptor, whereas
    libev and gevent have always supported many watchers using
    different settings. The libev behaviour is emulated at the Python
    level, but that adds overhead.

  - Looping multiple times and expecting events for the same file
    descriptor to be raised each time without any data being read or
    written (as works with libev) does not appear to work correctly on
    Linux when using ``gevent.select.poll`` or a monkey-patched
    ``selectors.PollSelector``.

  - The build system does not support using a system libuv; the
    embedded copy must be used. Using setuptools to compile libuv was
    the most portable method found.

  - If anything unexpected happens, libuv likes to ``abort()`` the
    entire process instead of reporting an error. For example, closing
    a file descriptor it is using in a watcher may cause the entire
    process to be exited.

  - There may be occasional otherwise unexplained and hard to
    duplicate crashes. If you can duplicate a crash, **please** submit
    an issue.

  - This is the only backend that PyPy can use on Windows. As of this
    alpha, there are many known issues with non-blocking sockets
    (e.g., as used by :mod:`asyncore`; see ``test_ftplib.py``) and
    sometimes sockets not getting closed in a timely fashion
    (apparently; see ``test_httpservers.py``) and communicating with
    subprocesses (it always hangs). Help tracking those down would be
    appreciated. Only PyPy2 is tested.

  Feedback and pull requests are welcome, especially to address the
  issues mentioned above.

  Other differences include:

  - The order in which timers and other callbacks are invoked may be
    different than in libev. In particular, timers and IO callbacks
    happen in a different order, and timers may easily be off by up to
    half of the supposed 1ms resolution. See :issue:`1057`.

  - Starting a ``timer`` watcher does not update the loop's time by
    default. This is because, unlike libev, a timer callback can cause
    other timer callbacks to be run if they expire because the loop's
    time updated, without cycling the event loop. See :issue:`1057`.

    libev has also been changed to follow this behaviour.

    Also see :issue:`1072`.

  - Timers of zero duration do not necessarily cause the event loop to
    cycle, as they do in libev. Instead, they may be called
    immediately. If zero duration timers are added from other zero
    duration timer callbacks, this can lead the loop to appear to
    hang, as no IO will actually be done.

    To mitigate this issue, ``loop.timer()`` detects attempts to use
    zero duration timers and turns them into a check watcher. check
    watchers do not support the ``again`` method.

  - All watchers (e.g., ``loop.io``) and the ``Timeout`` class have a
    ``close`` method that should be called when code is done using the
    object (they also function as context managers and a ``with``
    statement will automatically close them). gevent does this
    internally for sockets, file objects and internal timeouts.
    Neglecting to close an object may result in leaking native
    resources. To debug this, set the environment variables
    ``GEVENT_DEBUG=debug`` and ``PYTHONTRACEMALLOC=n`` before starting
    the process.

    The traditional cython-based libev backend will not leak if
    ``close`` is not called and will not produce warnings. The
    CFFI-based libev backend will not currently leak but will produce
    warnings. The CFFI-based libuv backend may leak and will produce
    warnings.

  Again, this is extremely experimental and all of it is subject to
  change.

  See :issue:`790` for history and more in-depth discussion.

libev
-----

- The C extension has been updated to use more modern Cython idioms
  and generate less code for simplicity, faster compilation and better
  cache usage. See :pr:`1077`.

  - Watcher objects may be slightly larger. On a 64-bit platform, a
    typical watcher may be 16 bytes (2 pointers) larger. This is
    offset by slight performance gains.

  - Cython is no longer preprocessed. Certain attributes that were
    previously only defined in certain compilation modes (notably
    LIBEV_EMBED) are now always defined, but will raise
    ``AttributeError`` or have a negative value when not available. In
    general these attributes are not portable or documented and are
    not implemented by libuv or the CFFI backend. See :issue:`1076`.

  - Certain private helper functions (``gevent_handle_error``, and part of
    ``gevent_call``) are now implemented in Cython instead of C. This
    reduces our reliance on internal undocumented implementation
    details of Cython and Python that could change. See :pr:`1080`.


1.2.2 (2017-06-05)
==================

- Testing on Python 3.5 now uses Python 3.5.3 due to SSL changes. See
  :issue:`943`.
- Linux CI has been updated from Ubuntu 12.04 to Ubuntu 14.04 since
  the former has reached EOL.
- Linux CI now tests on PyPy2 5.7.1, updated from PyPy2 5.6.0.
- Linux CI now tests on PyPy3 3.5-5.7.1-beta, updated from PyPy3
  3.3-5.5-alpha.
- Python 2 sockets are compatible with the ``SOCK_CLOEXEC`` flag found
  on Linux. They no longer pass the socket type or protocol to
  ``getaddrinfo`` when ``connect`` is called. Reported in :issue:`944`
  by Bernie Hackett.
- Replace ``optparse`` module with ``argparse``. See :issue:`947`.
- Update to version 1.3.1 of ``tblib`` to fix :issue:`954`,
  reported by ml31415.
- Fix the name of the ``type`` parameter to
  :func:`gevent.socket.getaddrinfo` to be correct on Python 3. This
  would cause callers using keyword arguments to raise a :exc:`TypeError`.
  Reported in :issue:`960` by js6626069. Likewise, correct the
  argument names for ``fromfd`` and ``socketpair`` on Python 2,
  although they cannot be called with keyword arguments under CPython.

  .. note:: The ``gethost*`` functions take different argument names
            under CPython and PyPy. gevent follows the CPython
            convention, although these functions cannot be called with
            keyword arguments on CPython.
- The previously-singleton exception objects ``FileObjectClosed`` and
  ``cancel_wait_ex`` were converted to classes. On Python 3, an
  exception object is stateful, including references to its context
  and possibly traceback, which could lead to objects remaining alive
  longer than intended.
- Make sure that ``python -m gevent.monkey <script>`` runs code in the
  global scope, not the scope of the ``main`` function. Fixed in
  :pr:`975` by Shawn Bohrer.

1.2.1 (2017-01-12)
==================

- CI services now test on 3.6.0.
- Windows: Provide ``socket.socketpair`` for all Python 3 versions.
  This was added to Python 3.5, but tests were only added in 3.6.
  (For versions older than 3.4 this is a gevent extension.) Previously
  this was not supported on any Python 3 version.
- Windows: List ``subprocess.STARTUPINFO`` in ``subprocess.__all__``
  for 3.6 compatibility.
- The ``_DummyThread`` objects created by calling
  :func:`threading.current_thread` from inside a raw
  :class:`greenlet.greenlet` in a system with monkey-patched
  ``threading`` now clean up after themselves when the
  greenlet dies (:class:`gevent.Greenlet`-based ``_DummyThreads`` have
  always cleaned up). This requires the use of a :class:`weakref.ref`
  (and may not be timely on PyPy).
  Reported in :issue:`918` by frozenoctobeer.
- Build OS X wheels with ``-D_DARWIN_FEATURE_CLOCK_GETTIME=0`` for
  compatibility with OS X releases before 10.12 Sierra. Reported by
  Ned Batchelder in :issue:`916`.

1.2.0 (2016-12-23)
==================

- The c-ares DNS resolver ignores bad flags to getnameinfo, like the
  system resolver does. Discovered when cleaning up the DNS resolver
  tests to produce more reliable results. See :issue:`774`.

1.2a2 (Dec 9, 2016)
===================

- Update libev to version 4.23.
- Allow the ``MAKE`` environment variable to specify the make command
  on non-Windows systems for ease of development on BSD systems where
  ``make`` is BSD make and ``gmake`` is GNU make (gevent requires GNU
  make). See :issue:`888`.
- Let :class:`gevent.server.StreamServer` accept an ``SSLContext`` on
  Python versions that support it. Added in :pr:`904` by Arcadiy Ivanov.

1.2a1 (Oct 27, 2016)
====================

Incompatible Changes
--------------------
- Support for Python 2.6 has been removed. See :pr:`766`.
- Remove module ``gevent.coros`` which was replaced by ``gevent.lock``
  and has been deprecated since 1.0b2.
- The internal implementation modules ``gevent.corecext`` and
  ``gevent.corecffi`` have been moved. Please import from
  ``gevent.core`` instead; this has always been the only documented place to
  import from.

Libraries and Installation
--------------------------

- Update libev to version 4.22 (was 4.20).
- Update tblib to 1.3.0.
- Update Cython to 0.25 (was 0.23.5).
- Update c-ares to version 1.12.0 (was 1.10.0) (`release notes <https://c-ares.haxx.se/changelog.html>`_).
- For the benefit of downstream package maintainers, gevent is now
  tested with c-ares and libev linked dynamically and not embedded
  (i.e., using the system libraries). However, only the versions
  shipped with gevent are tested and known to work.
- The repository directory layout has been changed to make it easier
  to include third-party dependencies. Likewise, the setup.py script
  has been split to make it easier to build third-party dependencies.
- PyPy/CFFI: The corecffi native extension is now only built at
  installation time. Previously, if it wasn't available, a build was
  attempted at every import. This could lead to scattered "gevent"
  directories and undependable results.
- setuptools is now required at build time on all platforms.
  Previously it was only required for Windows and PyPy.
- POSIX: Don't hardcode ``/bin/sh`` into the configuration command
  line, instead relying on ``sh`` being on the ``PATH``, as
  recommended by `the standard <http://pubs.opengroup.org/onlinepubs/9699919799/utilities/sh.html>`_.
  Fixed in :pr:`809` by Fredrix Fornwall.

Security
--------
- :mod:`gevent.pywsgi` now checks that the values passed to
  ``start_response`` do not contain a carriage return or newline in
  order to prevent HTTP response splitting (header injection), raising
  a :exc:`ValueError` if they do. See :issue:`775`.
- Incoming headers containing an underscore are no longer placed in
  the WSGI environ. See :issue:`819`.
- Errors logged by :class:`~gevent.pywsgi.WSGIHandler` no
  longer print the entire WSGI environment by default. This avoids
  possible information disclosure vulnerabilities. Applications can
  also opt-in to a higher security level for the WSGI environment if they
  choose and their frameworks support it. Originally reported
  in :pr:`779` by sean-peters-au and changed in :pr:`781`.

Platforms
---------

- As mentioned above, Python 2.6 is no longer supported.
- Python 3.6 is now tested on POSIX platforms. This includes a few
  notable changes:

  * SSLContext.wrap_socket accepts the ``session`` parameter, though
    this parameter isn't useful prior to 3.6.
  * SSLSocket.recv(0) or read(0) returns an empty byte string. This is
    a fix for `Python bug #23804 <http://bugs.python.org/issue23804>`_
    which has also been merged into Python 2.7 and Python 3.5.
- PyPy3 5.5.0 *alpha* (supporting Python 3.3.5) is now tested and passes the
  test suite. Thanks to btegs for :issue:`866`, and Fabio Utzig for :pr:`826`.
  Note that PyPy3 is not optimized for performance either by the PyPy
  developers or under gevent, so it may be significantly slower than PyPy2.

Stdlib Compatibility
--------------------
- The modules :mod:`gevent.os`, :mod:`gevent.signal` and
  :mod:`gevent.select` export all the attributes from their
  corresponding standard library counterpart.
- Python 2: ``reload(site)`` no longer fails with a ``TypeError`` if
  gevent has been imported. Reported in :issue:`805` by Jake Hilton.
- Python 2: ``sendall`` on a non-blocking socket could spuriously fail
  with a timeout.

select/poll
~~~~~~~~~~~

- If :func:`gevent.select.select` is given a negative *timeout*
  argument, raise an exception like the standard library does.
- If :func:`gevent.select.select` is given closed or invalid
  file descriptors in any of its lists, raise the appropriate
  ``EBADF`` exception like the standard library does. Previously,
  libev would tend to return the descriptor as ready. In the worst
  case, this adds an extra system call, but may also reduce latency if
  descriptors are ready at the time of entry.
- :class:`selectors.SelectSelector` is properly monkey-patched
  regardless of the order of imports. Reported in :issue:`835` by
  Przemysław Węgrzyn.
- :meth:`gevent.select.poll.unregister` raises an exception if *fd* is not
  registered, like the standard library.
- :meth:`gevent.select.poll.poll` returns an event with
  ``POLLNVAL`` for registered fds that are invalid. Previously it
  would tend to report both read and write events.


File objects
~~~~~~~~~~~~

- ``FileObjectPosix`` exposes the ``read1`` method when in read mode,
  and generally only exposes methods appropriate to the mode it is in.
- ``FileObjectPosix`` supports a *bufsize* of 0 in binary write modes.
  Reported in :issue:`840` by Mike Lang.
- Python 3: :meth:`gevent.socket.connect_ex` was letting
  ``BlockingIOError`` (and possibly others) get raised instead of
  returning the errno due to the refactoring of the exception
  hierarchy in Python 3.3. Now the errno is returned. Reported in
  :issue:`841` by Dana Powers.


Other Changes
-------------

- :class:`~.Group` and :class:`~.Pool` now return whether
  :meth:`~.Group.join` returned with an empty group. Suggested by Filippo Sironi in
  :pr:`503`.
- Unhandled exception reports that kill a greenlet now include a
  timestamp. See :issue:`137`.
- :class:`~.PriorityQueue` now ensures that an initial items list is a
  valid heap. Fixed in :pr:`793` by X.C.Dong.
- :class:`gevent.hub.signal` (aka :func:`gevent.signal`) now verifies
  that its `handler` argument is callable, raising a :exc:`TypeError`
  if it isn't. Reported in :issue:`818` by Peter Renström.
- If ``sys.stderr`` has been monkey-patched (not recommended),
  exceptions that the hub reports aren't lost and can still be caught.
  Reported in :issue:`825` by Jelle Smet.
- The :func:`gevent.os.waitpid` function is cooperative in more
  circumstances. Reported in :issue:`878` by Heungsub Lee.
- The various ``FileObject`` implementations are more consistent with
  each other. **Note:** Writing to the *io* property of a FileObject should be
  considered deprecated.
- Timeout exceptions (and other asynchronous exceptions) could cause
  the BackdoorServer to fail to properly manage the
  stdout/stderr/stdin values. Reported with a patch in :pr:`874` by
  stefanmh.
- The BackDoorServer now tracks spawned greenlets (connections) and
  kills them in its ``stop`` method.

Servers
~~~~~~~
- Default to AF_INET6 when binding to all addresses (e.g.,
  ""). This supports both IPv4 and IPv6 connections (except on
  Windows). Original change in :pr:`495` by Felix Kaiser.
- pywsgi/performance: Chunks of data the application returns are no longer copied
  before being sent to the socket when the transfer-encoding is
  chunked, potentially reducing overhead for large responses.

Threads
~~~~~~~
- Add :class:`gevent.threadpool.ThreadPoolExecutor` (a
  :class:`concurrent.futures.ThreadPoolExecutor` variant that always
  uses native threads even when the system has been monkey-patched)
  on platforms that have ``concurrent.futures``
  available (Python 3 and Python 2 with the ``futures`` backport
  installed). This is helpful for, e.g., grpc. Reported in
  :issue:`786` by Markus Padourek.
- Native threads created before monkey-patching threading can now be
  joined. Previously on Python < 3.4, doing so would raise a
  ``LoopExit`` error. Reported in :issue:`747` by Sergey Vasilyev.

SSL
~~~
- On Python 2.7.9 and above (more generally, when the SSL backport is
  present in Python 2), :func:`gevent.ssl.get_server_certificate`
  would raise a :exc:`ValueError` if the system wasn't monkey-patched.
  Reported in :issue:`801` by Gleb Dubovik.
- On Python 2.7.9 and Python 3, closing an SSL socket in one greenlet
  while it's being read from or written to in a different greenlet is
  less likely to raise a :exc:`TypeError` instead of a
  :exc:`ValueError`. Reported in :issue:`800` by Kevin Chen.


subprocess module
~~~~~~~~~~~~~~~~~

- Setting SIGCHLD to SIG_IGN or SIG_DFL after :mod:`gevent.subprocess`
  had been used previously could not be reversed, causing
  ``Popen.wait`` and other calls to hang. Now, if SIGCHLD has been
  ignored, the next time :mod:`gevent.subprocess` is used this will be
  detected and corrected automatically. (This potentially leads to
  issues with :func:`os.popen` on Python 2, but the signal can always
  be reset again. Mixing the low-level process handling calls,
  low-level signal management and high-level use of
  :mod:`gevent.subprocess` is tricky.) Reported in :issue:`857` by
  Chris Utz.
- ``Popen.kill`` and ``send_signal`` no longer attempt to send signals
  to processes that are known to be exited.

Several backwards compatible updates to the subprocess module have
been backported from Python 3 to Python 2, making
:mod:`gevent.subprocess` smaller, easier to maintain and in some cases
safer.

- Popen objects can be used as context managers even on Python 2. The
  high-level API functions (``call``, etc) use this for added safety.
- The :mod:`gevent.subprocess` module now provides the
  :func:`gevent.subprocess.run` function in a cooperative way even
  when the system is not monkey patched, on all supported versions of
  Python. (It was added officially in Python 3.5.)
- Popen objects save their *args* attribute even on Python 2.
- :exc:`gevent.subprocess.TimeoutExpired` is defined even on Python 2,
  where it is a subclass of the :exc:`gevent.timeout.Timeout`
  exception; all instances where a ``Timeout`` exception would
  previously be thrown under Python 2 will now throw a
  ``TimeoutExpired`` exception.
- :func:`gevent.subprocess.call` (and ``check_call``) accepts the
  *timeout* keyword argument on Python 2. This is standard on Python
  3, but a gevent extension on Python 2.
- :func:`gevent.subprocess.check_output` accepts the *timeout* and
  *input* arguments on Python 2. This is standard on Python 3, but a
  gevent extension on Python 2.


1.1.2 (Jul 21, 2016)
====================

- Python 2: ``sendall`` on a non-blocking socket could spuriously fail
  with a timeout.
- If ``sys.stderr`` has been monkey-patched (not recommended),
  exceptions that the hub reports aren't lost and can still be caught.
  Reported in :issue:`825` by Jelle Smet.
- :class:`selectors.SelectSelector` is properly monkey-patched
  regardless of the order of imports. Reported in :issue:`835` by
  Przemysław Węgrzyn.
- Python 2: ``reload(site)`` no longer fails with a ``TypeError`` if
  gevent has been imported. Reported in :issue:`805` by Jake Hilton.

1.1.1 (Apr 4, 2016)
===================

- Nested callbacks that set and clear an Event no longer cause
  ``wait`` to return prematurely. Reported in :issue:`771` by Sergey
  Vasilyev.
- Fix build on Solaris 10. Reported in :issue:`777` by wiggin15.
- The ``ref`` parameter to :func:`gevent.os.fork_and_watch` was being ignored.
- Python 3: :class:`gevent.queue.Channel` is now correctly iterable, instead of
  raising a :exc:`TypeError`.
- Python 3: Add support for :meth:`socket.socket.sendmsg`,
  :meth:`socket.socket.recvmsg` and :meth:`socket.socket.recvmsg_into`
  on platforms where they are defined. Initial :pr:`773` by Jakub
  Klama.

1.1.0 (Mar 5, 2016)
===================

- Python 3: A monkey-patched :class:`threading.RLock` now properly
  blocks (or deadlocks) in ``acquire`` if the default value for
  *timeout* of -1 is used (which differs from gevent's default of
  None). The ``acquire`` method also raises the same :exc:`ValueError`
  exceptions that the standard library does for invalid parameters.
  Reported in :issue:`750` by Joy Zheng.
- Fix a race condition in :class:`~gevent.event.Event` that made it
  return ``False`` when the event was set and cleared by the same
  greenlet before allowing a switch to already waiting greenlets. (Found
  by the 3.4 and 3.5 standard library test suites; the same as Python
  `bug 13502`_. Note that the Python 2 standard library still has this
  race condition.)
- :class:`~gevent.event.Event` and :class:`~.AsyncResult` now wake
  waiting greenlets in the same (unspecified) order. Previously,
  ``AsyncResult`` tended to use a FIFO order, but this was never
  guaranteed. Both classes also use less per-instance memory.
- Using a :class:`~logging.Logger` as a :mod:`pywsgi` error or request
  log stream no longer produces extra newlines. Reported in
  :issue:`756` by ael-code.
- Windows: Installing from an sdist (.tar.gz) on PyPI no longer
  requires having Cython installed first. (Note that the binary installation
  formats (wheels, exes, msis) are preferred on Windows.) Reported in
  :issue:`757` by Ned Batchelder.
- Issue a warning when :func:`~gevent.monkey.patch_all` is called with
  ``os`` set to False (*not* the default) but ``signal`` is still True
  (the default). This combination of parameters will cause signal
  handlers for ``SIGCHLD`` to not get called. In the future this might
  raise an error. Reported by Josh Zuech.
- Issue a warning when :func:`~gevent.monkey.patch_all` is called more
  than once with different arguments. That causes the cumulative set of all True
  arguments to be patched, which may cause unexpected results.
- Fix returning the original values of certain ``threading``
  attributes from :func:`gevent.monkey.get_original`.

.. _bug 13502: http://bugs.python.org/issue13502

1.1rc5 (Feb 24, 2016)
=====================

- SSL: Attempting to send empty data using the
  :meth:`~socket.socket.sendall` method of a gevent SSL socket that has
  a timeout now returns immediately (like the standard library does),
  instead of incorrectly raising :exc:`ssl.SSLEOFError`. (Note that
  sending empty data with the :meth:`~socket.socket.send`
  method *does* raise ``SSLEOFError`` in
  both gevent and the standard library.) Reported in :issue:`719` by
  Mustafa Atik and Tymur Maryokhin, with a reproducible test case
  provided by Timo Savola.

1.1rc4 (Feb 16, 2016)
=====================

- Python 2: Using the blocking API at import time when multiple
  greenlets are also importing should not lead to ``LoopExit``.
  Reported in :issue:`728` by Garrett Heel.
- Python 2: Don't raise :exc:`OverflowError` when using the ``readline``
  method of the WSGI input stream without a size hint or with a large
  size hint when the client is uploading a large amount of data. (This
  only impacted CPython 2; PyPy and Python 3 already handled this.)
  Reported in :issue:`289` by ggjjlldd, with contributions by Nathan
  Hoad.
- :class:`~gevent.baseserver.BaseServer` and its subclasses like
  :class:`~gevent.pywsgi.WSGIServer` avoid allocating a new closure for
  each request, reducing overhead.
- Python 2: Under 2.7.9 and above (or when the PEP 466 SSL interfaces
  are available), perform the same hostname validation that the
  standard library does; previously this was skipped. Also,
  reading, writing, or handshaking a closed
  :class:`~ssl.SSLSocket` now raises the same :exc:`ValueError`
  the standard library does, instead of an :exc:`AttributeError`.
  Found by updating gevent's copy of the standard library test cases.
  Initially reported in :issue:`735` by Dmitrij D. Czarkoff.
- Python 3: Fix :meth:`~ssl.SSLSocket.unwrap` and SNI callbacks.
  Also raise the correct exceptions for unconnected SSL sockets and
  properly validate SSL hostnames. Found via updated standard library
  tests.
- Python 3: Add missing support for :meth:`socket.socket.sendfile`. Found via updated
  standard library tests.
- Python 3.4+: Add missing support for
  :meth:`socket.socket.get_inheritable` and
  :meth:`~socket.socket.set_inheritable`. Found via updated standard
  library tests.

1.1rc3 (Jan 04, 2016)
=====================

- Python 2: Support the new PEP 466 :mod:`ssl` interfaces on any Python 2
  version that supplies them, not just on the versions it officially
  shipped with. Some Linux distributions, including RedHat/CentOS and
  Amazon have backported the changes to older versions. Reported in
  :issue:`702`.
- PyPy: An interaction between Cython compiled code and the garbage
  collector caused PyPy to crash when a previously-allocated Semaphore
  was used in a ``__del__`` method, something done in the popular
  libraries ``requests`` and ``urllib3``. Due to this and other Cython
  related issues, the Semaphore class is no longer compiled by Cython
  on PyPy. This means that it is now traceable and not exactly as
  atomic as the Cython version, though the overall semantics should
  remain the same. Reported in :issue:`704` by Shaun Crampton.
- PyPy: Optimize the CFFI backend to use less memory (two pointers per
  watcher).
- Python 3: The WSGI ``PATH_INFO`` entry is decoded from URL escapes
  using latin-1, not UTF-8. This improves compliance with PEP 3333 and
  compatibility with some frameworks like Django. Fixed in :pr:`712`
  by Ruben De Visscher.

1.1rc2 (Dec 11, 2015)
=====================

- Exceptions raised by gevent's SSL sockets are more consistent with
  the standard library (e.g., gevent's Python 3 SSL sockets raise
  :exc:`socket.timeout` instead of :exc:`ssl.SSLError`, a change
  introduced in Python 3.2).
- Python 2: gevent's socket's ``sendall`` method could completely ignore timeouts
  in some cases. The timeout now refers to the total time taken by
  ``sendall``.
- gevent's SSL socket's ``sendall`` method should no longer raise ``SSL3_WRITE_PENDING``
  in rare cases when sending large buffers. Reported in :issue:`317`.
- :func:`gevent.signal.signal` now allows resetting (SIG_DFL) and ignoring (SIG_IGN) the
  SIGCHLD signal at the process level (although this may allow race
  conditions with libev child watchers). Reported in :issue:`696` by
  Adam Ning.
- :func:`gevent.spawn_raw` now accepts keyword arguments, as
  previously (incorrectly) documented. Reported in :issue:`680` by Ron
  Rothman.
- PyPy: PyPy 2.6.1 or later is now required (4.0.1 or later is
  recommended).
- The CFFI backend is now built and usable on CPython implementations
  (except on Windows) if ``cffi`` is installed before gevent is
  installed. To use the CFFI backend, set the environment variable
  ``GEVENT_CORE_CFFI_ONLY`` before starting Python. This can aid
  debugging in some cases and helps ensure parity across all
  combinations of supported platforms.
- The CFFI backend now calls the callback of a watcher whose ``args`` attribute is
  set to ``None``, just like the Cython backend does. It also only
  allows ``args`` to be a tuple or ``None``, again matching the Cython backend.
- PyPy/CFFI: Fix a potential crash when using stat watchers.
- PyPy/CFFI: Encode unicode paths for stat watchers using
  :meth:`sys.getfilesystemencoding` like the Cython backend.
- The internal implementation modules ``gevent._fileobject2``,
  ``gevent._fileobject3``, and ``gevent._util`` were removed. These
  haven't been used or tested since 1.1b1.


1.1rc1 (Nov 14, 2015)
=====================

- Windows/Python 3: Finish porting the :mod:`gevent.subprocess` module, fixing a
  large number of failing tests. Examples of failures are in
  :issue:`668` and :issue:`669` reported by srossross.
- Python 3: The SSLSocket class should return an empty ``bytes``
  object on an EOF instead of a ``str``. Fixed in :pr:`674` by Dahoon
  Kim.
- Python 2: Workaround a buffering bug in the stdlib ``io`` module
  that caused ``FileObjectPosix`` to be slower than necessary in some
  cases. Reported in :issue:`675` by WGH-.
- PyPy: Fix a crash. Reported in :issue:`676` by Jay Oster.

  .. caution:: There are some remaining, relatively rare, PyPy
               crashes, but their ultimate cause is unknown (gevent,
               CFFI, greenlet, the PyPy GC?). PyPy users can
               contribute to :issue:`677` to help track them down.
- PyPy: Exceptions raised while handling an error raised by a loop
  callback function behave like the CPython implementation: the
  exception is printed, and the rest of the callbacks continue
  processing.
- If a Hub object with active watchers was destroyed and then another
  one created for the same thread, which itself was then destroyed with
  ``destroy_loop=True``, the process could crash. Documented in
  :issue:`237` and fix based on :pr:`238`, both by Jan-Philip Gehrcke.
- Python 3: Initializing gevent's hub for the first time
  simultaneously in multiple native background threads could fail with
  ``AttributeError`` and ``ImportError``. Reported in :issue:`687` by
  Gregory Petukhov.

1.1b6 (Oct 17, 2015)
====================

- PyPy: Fix a memory leak for code that allocated and disposed of many
  :class:`gevent.lock.Semaphore` subclasses. If monkey-patched, this could
  also apply to :class:`threading.Semaphore` objects. Reported in
  :issue:`660` by Jay Oster.
- PyPy: Cython version 0.23.4 or later must be used to avoid a memory
  leak (`details`_). Thanks to Jay Oster.
- Allow subclasses of :class:`~.WSGIHandler` to handle invalid HTTP client
  requests. Reported by not-bob.
- :class:`~.WSGIServer` more robustly supports :class:`~logging.Logger`-like parameters for
  ``log`` and ``error_log`` (as introduced in 1.1b1, this could cause
  integration issues with gunicorn). Reported in :issue:`663` by Jay
  Oster.
- :class:`~gevent.threading._DummyThread` objects, created in a
  monkey-patched system when :func:`threading.current_thread` is
  called in a new greenlet (which often happens implicitly, such as
  when logging) are much lighter weight. For example, they no longer
  allocate and then delete a :class:`~gevent.lock.Semaphore`, which is
  especially important for PyPy.
- Request logging by :mod:`gevent.pywsgi` formats the status code
  correctly on Python 3. Reported in :issue:`664` by Kevin Chen.
- Restore the ability to take a weak reference to instances of exactly
  :class:`gevent.lock.Semaphore`, which was unintentionally removed
  as part of making ``Semaphore`` atomic on PyPy on 1.1b1. Reported in
  :issue:`666` by Ivan-Zhu.
- Build Windows wheels for Python 3.5. Reported in :pr:`665` by Hexchain Tong.

.. _details: https://mail.python.org/pipermail/cython-devel/2015-October/004571.html

1.1b5 (Sep 18, 2015)
====================

- :mod:`gevent.subprocess` works under Python 3.5. In general, Python 3.5
  has preliminary support. Reported in :issue:`653` by Squeaky.
- :func:`Popen.communicate <gevent.subprocess.Popen.communicate>` honors a ``timeout``
  argument even if there is no way to communicate with the child
  process (none of stdin, stdout and stderr were set to ``PIPE``).
  Noticed as part of the Python 3.5 test suite for the new function
  ``subprocess.run`` but impacts all versions (``timeout`` is an
  official argument under Python 3 and a gevent extension with
  slightly different semantics under Python 2).
- Fix a possible ``ValueError`` from :meth:`Queue.peek <gevent.queue.Queue.peek>`.
  Reported in :issue:`647` by Kevin Chen.
- Restore backwards compatibility for using ``gevent.signal`` as a
  callable, which, depending on the order of imports, could be broken
  after the addition of the ``gevent.signal`` module. Reported in
  :issue:`648` by Sylvain Zimmer.
- gevent blocking operations performed at the top-level of a module
  after the system was monkey-patched under Python 2 could result in
  raising a :exc:`~gevent.hub.LoopExit` instead of completing the expected blocking
  operation. Note that performing gevent blocking operations in the
  top-level of a module is typically not recommended, but this
  situation can arise when monkey-patching existing scripts. Reported
  in :issue:`651` and :issue:`652` by Mike Kaplinskiy.
- ``SIGCHLD`` and ``waitpid`` now work for the pids returned by the
  (monkey-patched) ``os.forkpty`` and ``pty.fork`` functions in the
  same way they do for the ``os.fork`` function. Reported in
  :issue:`650` by Erich Heine.
- :class:`~gevent.pywsgi.WSGIServer` and
  :class:`~gevent.pywsgi.WSGIHandler` do a better job detecting and
  reporting potential encoding errors for headers and the status line
  during :meth:`~gevent.pywsgi.WSGIHandler.start_response` as recommended by the `WSGI
  specification`_. In addition, under Python 2, unnecessary encodings
  and decodings (often a trip through the ASCII encoding) are avoided
  for conforming applications. This is an enhancement of an already
  documented and partially enforced constraint: beginning in 1.1a1,
  under Python 2, ``u'abc'`` would typically previously have been
  allowed, but ``u'\u1f4a3'`` would not; now, neither will be allowed,
  more closely matching the specification, improving debugability and
  performance and allowing for better error handling both by the
  application and by gevent (previously, certain encoding errors could
  result in gevent writing invalid/malformed HTTP responses). Reported
  by Greg Higgins and Carlos Sanchez.
- Code coverage by tests is now reported on `coveralls.io`_.

.. _WSGI specification: https://www.python.org/dev/peps/pep-3333/#the-start-response-callable
.. _coveralls.io: https://coveralls.io/github/gevent/gevent

1.1b4 (Sep 4, 2015)
===================

- Detect and raise an error for several important types of
  programming errors even if Python interpreter optimizations are
  enabled with ``-O`` or ``PYTHONOPTIMIZE``. Previously these would go
  undetected if optimizations were enabled, potentially leading to
  erratic, difficult to debug behaviour.
- Fix an ``AttributeError`` from ``gevent.queue.Queue`` when ``peek``
  was called on an empty ``Queue``. Reported in :issue:`643` by michaelvol.
- Make ``SIGCHLD`` handlers specified to :func:`gevent.signal.signal` work with
  the child watchers that are used by default. Also make
  :func:`gevent.os.waitpid` work with a first argument of -1. (Also
  applies to the corresponding monkey-patched stdlib functions.)
  Noted by users of gunicorn.
- Under Python 2, any timeout set on a socket would be ignored when
  using the results of ``socket.makefile``. Reported in :issue:`644`
  by Karan Lyons.

1.1b3 (Aug 16, 2015)
====================

- Fix an ``AttributeError`` from ``gevent.monkey.patch_builtins`` on
  Python 2 when the `future`_ library is also installed. Reported by
  Carlos Sanchez.
- PyPy: Fix a ``DistutilsModuleError`` or ``ImportError`` if the CFFI
  module backing ``gevent.core`` needs to be compiled when the hub is
  initialized (due to a missing or invalid ``__pycache__`` directory).
  Now, the module will be automtically compiled when gevent is
  imported (this may produce compiler output on stdout). Reported in
  :issue:`619` by Thinh Nguyen and :issue:`631` by Andy Freeland, with
  contributions by Jay Oster and Matt Dupre.
- PyPy: Improve the performance of ``gevent.socket.socket:sendall``
  with large inputs. `bench_sendall.py`_ now performs about as well on
  PyPy as it does on CPython, an improvement of 10x (from ~60MB/s to
  ~630MB/s). See this `pypy bug`_ for details.
- Fix a possible ``TypeError`` when calling ``gevent.socket.wait``.
  Reported in #635 by lanstin.
- ``gevent.socket.socket:sendto`` properly respects the socket's
  blocking status (meaning it can raise EWOULDBLOCK now in cases it
  wouldn't have before). Reported in :pr:`634` by Mike Kaplinskiy.
- Common lookup errors using the :mod:`threaded resolver
  <gevent.resolver_thread>` are no longer always printed to stderr
  since they are usually out of the programmer's control and caught
  explicitly. (Programming errors like ``TypeError`` are still
  printed.) Reported in :issue:`617` by Jay Oster and Carlos Sanchez.
- PyPy: Fix a ``TypeError`` from ``gevent.idle()``. Reported in
  :issue:`639` by chilun2008.
- The :func:`~gevent.pool.Pool.imap_unordered` methods of a pool-like
  object support a ``maxsize`` parameter to limit the number of
  results buffered waiting for the consumer. Reported in :issue:`638`
  by Sylvain Zimmer.
- The class :class:`gevent.queue.Queue` now consistently orders multiple
  blocked waiting ``put`` and ``get`` callers in the order they
  arrived. Previously, due to an implementation quirk this was often
  roughly the case under CPython, but not under PyPy. Now they both
  behave the same.
- The class :class:`gevent.queue.Queue` now supports the :func:`len` function.

.. _future: http://python-future.org
.. _bench_sendall.py: https://raw.githubusercontent.com/gevent/gevent/master/greentest/bench_sendall.py
.. _pypy bug: https://bitbucket.org/pypy/pypy/issues/2091/non-blocking-socketsend-slow-gevent

1.1b2 (Aug 5, 2015)
===================

- Enable using the :mod:`c-ares resolver <gevent.resolver_ares>` under
  PyPy. Note that its performance characteristics are probably
  sub-optimal.
- On some versions of PyPy on some platforms (notably 2.6.0 on 64-bit
  Linux), enabling ``gevent.monkey.patch_builtins`` could cause PyPy
  to crash. Reported in :issue:`618` by Jay Oster.
- :func:`gevent.kill` raises the correct exception in the target greenlet.
  Reported in :issue:`623` by Jonathan Kamens.
- Various fixes on Windows. Reported in :issue:`625`, :issue:`627`,
  and :issue:`628` by jacekt and Yuanteng (Jeff) Pei. Fixed in :pr:`624`.
- Add :meth:`~gevent.fileobject.FileObjectPosix.readable` and
  :meth:`~gevent.fileobject.FileObjectPosix.writable` methods to
  :class:`~gevent.fileobject.FileObjectPosix`; this fixes e.g., help() on Python 3 when
  monkey-patched.

1.1b1 (Jul 17, 2015)
====================

- ``setup.py`` can be run from a directory containing spaces. Reported
  in :issue:`319` by Ivan Smirnov.
- ``setup.py`` can build with newer versions of clang on OS X. They
  enforce the distinction between CFLAGS and CPPFLAGS.
- ``gevent.lock.Semaphore`` is atomic on PyPy, just like it is on
  CPython. This comes at a small performance cost on PyPy.
- Fixed regression that failed to set the ``successful`` value to
  False when killing a greenlet before it ran with a non-default
  exception. Fixed in :pr:`608` by Heungsub Lee.
- libev's child watchers caused :func:`os.waitpid` to become unreliable
  due to the use of signals on POSIX platforms. This was especially
  noticeable when using :mod:`gevent.subprocess` in combination with
  ``multiprocessing``. Now, the monkey-patched ``os`` module provides
  a :func:`~gevent.os.waitpid` function that seeks to ameliorate this. Reported in
  :issue:`600` by champax and :issue:`452` by Łukasz Kawczyński.
- On platforms that implement :class:`select.poll`, provide a
  gevent-friendly :class:`gevent.select.poll` and corresponding
  monkey-patch. Implemented in :pr:`604` by Eddi Linder.
- Allow passing of events to the io callback under PyPy. Reported in
  :issue:`531` by M. Nunberg and implemented in :pr:`604`.
- :func:`gevent.thread.allocate_lock` (and so a monkey-patched standard
  library :func:`~thread.allocate_lock`) more closely matches the behaviour of the
  builtin: an unlocked lock cannot be released, and attempting to do
  so throws the correct exception (``thread.error`` on Python 2,
  ``RuntimeError`` on Python 3). Previously, over-releasing a lock was
  silently ignored. Reported in :issue:`308` by Jędrzej Nowak.
- :class:`gevent.fileobject.FileObjectThread` uses the threadpool to close
  the underling file-like object. Reported in :issue:`201` by
  vitaly-krugl.
- Malicious or malformed HTTP chunked transfer encoding data sent to
  the :class:`pywsgi handler <gevent.pywsgi.WSGIHandler>` is handled more robustly, resulting in
  "HTTP 400 bad request" responses instead of a 500 error or, in the
  worst case, a server-side hang. Reported in :issue:`229` by Björn
  Lindqvist.
- Importing the standard library ``threading`` module *before* using
  ``gevent.monkey.patch_all()`` no longer causes Python 3.4 to fail to
  get the ``repr`` of the main thread, and other CPython platforms to
  return an unjoinable DummyThread. (Note that this is not
  recommended.) Reported in :issue:`153`.
- Under Python 2, use the ``io`` package to implement
  :class:`~gevent.fileobject.FileObjectPosix`. This unifies the code with the Python 3
  implementation, and fixes problems with using ``seek()``. See
  :issue:`151`.
- Under Python 2, importing a module that uses gevent blocking
  functions at its top level from multiple greenlets no longer
  produces import errors (Python 3 handles this case natively).
  Reported in :issue:`108` by shaun and initial fix based on code by
  Sylvain Zimmer.
- :func:`gevent.spawn`, :func:`spawn_raw` and :func:`spawn_later`, as well as the
  :class:`~gevent.Greenlet` constructor, immediately produce useful ``TypeErrors``
  if asked to run something that cannot be run. Previously, the
  spawned greenlet would die with an uncaught ``TypeError`` the first
  time it was switched to. Reported in :issue:`119` by stephan.
- Recursive use of :meth:`ThreadPool.apply
  <gevent.threadpool.ThreadPool.apply>` no longer raises a
  ``LoopExit`` error (using ``ThreadPool.spawn`` and then ``get`` on
  the result still could; you must be careful to use the correct hub).
  Reported in :issue:`131` by 8mayday.
- When the :mod:`threading` module is :func:`monkey-patched
  <gevent.monkey.patch_thread>`, the module-level lock in the
  :mod:`logging` module is made greenlet-aware, as are the instance
  locks of any configured handlers. This makes it safer to import
  modules that use the standard pattern of creating a module-level
  :class:`~logging.Logger` instance before monkey-patching.
  Configuring ``logging`` with a basic configuration and then
  monkey-patching is also safer (but not configurations that involve
  such things as the ``SocketHandler``).
- Fix monkey-patching of :class:`threading.RLock` under Python 3.
- Under Python 3, monkey-patching at the top-level of a module that
  was imported by another module could result in a :exc:`RuntimeError`
  from :mod:`importlib`. Reported in :issue:`615` by Daniel Mizyrycki.
  (The same thing could happen under Python 2 if a ``threading.RLock``
  was held around the monkey-patching call; this is less likely but
  not impossible with import hooks.)
- Fix configuring c-ares for a 32-bit Python when running on a 64-bit
  platform. Reported in :issue:`381` and fixed in :pr:`616` by Chris
  Lane. Additional fix in :pr:`626` by Kevin Chen.
- (Experimental) Let the :class:`pywsgi.WSGIServer` accept a
  :class:`logging.Logger` instance for its ``log`` and (new) ``error_log``
  parameters. Take care that the system is fully monkey-patched very
  early in the process's lifetime if attempting this, and note that
  non-file handlers have not been tested. Fixes :issue:`106`.

1.1a2 (Jul 8, 2015)
===================

- ``gevent.threadpool.ThreadPool.imap`` and ``imap_unordered`` now
  accept multiple iterables.
- (Experimental) Exceptions raised from iterating using the
  ``ThreadPool`` or ``Group`` mapping/application functions should now
  have the original traceback.
- :meth:`gevent.threadpool.ThreadPool.apply` now raises any exception
  raised by the called function, the same as
  :class:`~gevent.pool.Group`/:class:`~gevent.pool.Pool` and the
  builtin :func:`apply` function. This obsoletes the undocumented
  ``apply_e`` function. Original PR :issue:`556` by Robert Estelle.
- Monkey-patch the ``selectors`` module from ``patch_all`` and
  ``patch_select`` on Python 3.4. See :issue:`591`.
- Additional query functions for the :mod:`gevent.monkey` module
  allow knowing what was patched. Discussed in :issue:`135` and
  implemented in :pr:`325` by Nathan Hoad.
- In non-monkey-patched environments under Python 2.7.9 or above or
  Python 3, using a gevent SSL socket could cause the greenlet to
  block. See :issue:`597` by David Ford.
- :meth:`gevent.socket.socket.sendall` supports arbitrary objects that
  implement the buffer protocol (such as ctypes structures), just like
  native sockets. Reported in :issue:`466` by tzickel.
- Added support for the ``onerror`` attribute present in CFFI 1.2.0
  for better signal handling under PyPy. Thanks to Armin Rigo and Omer
  Katz. (See https://bitbucket.org/cffi/cffi/issue/152/handling-errors-from-signal-handlers-in)
- The :mod:`gevent.subprocess` module is closer in behaviour to the
  standard library under Python 3, at least on POSIX. The
  ``pass_fds``, ``restore_signals``, and ``start_new_session``
  arguments are now implemented, as are the ``timeout`` parameters
  to various functions. Under Python 2, the previously undocumented
  ``timeout`` parameter to :meth:`Popen.communicate
  <gevent.subprocess.Popen.communicate>` raises an exception like its
  Python 3 counterpart.
- An exception starting a child process with the :mod:`gevent.subprocess`
  module no longer leaks file descriptors. Reported in :pr:`374` by 陈小玉.
- The example ``echoserver.py`` no longer binds to the standard X11
  TCP port. Reported in :issue:`485` by minusf.
- :func:`gevent.iwait` no longer throws :exc:`~gevent.hub.LoopExit` if the caller
  switches greenlets between return values. Reported and initial patch
  in :issue:`467` by Alexey Borzenkov.
- The default threadpool and default threaded resolver work in a
  forked child process, such as with :class:`multiprocessing.Process`.
  Previously the child process would hang indefinitely. Reported in
  :issue:`230` by Lx Yu.
- Fork watchers are more likely to (eventually) get called in a
  multi-threaded program (except on Windows). See :issue:`154`.
- :func:`gevent.killall` accepts an arbitrary iterable for the greenlets
  to kill. Reported in :issue:`404` by Martin Bachwerk; seen in
  combination with older versions of simple-requests.
- :class:`gevent.local.local` objects are now eligible for garbage
  collection as soon as the greenlet finishes running, matching the
  behaviour of the built-in :class:`threading.local` (when implemented
  natively). Reported in :issue:`387` by AusIV.
- Killing a greenlet (with :func:`gevent.kill` or
  :meth:`gevent.Greenlet.kill`) before it is actually started and
  switched to now prevents the greenlet from ever running, instead of
  raising an exception when it is later switched to. See :issue:`330`
  reported by Jonathan Kamens.

1.1a1 (Jun 29, 2015)
====================

- Add support for Python 3.3 and 3.4. Many people have contributed to
  this effort, including but not limited to Fantix King, hashstat,
  Elizabeth Myers, jander, Luke Woydziak, and others. See :issue:`38`.
- Add support for PyPy. See :issue:`248`. Note that for best results,
  you'll need a very recent PyPy build including CFFI 1.2.0.
- Drop support for Python 2.5. Python 2.5 users can continue to use
  gevent 1.0.x.
- Fix :func:`gevent.joinall` to not ignore ``count`` when
  ``raise_error`` is False. See :pr:`512` by Ivan Diao.
- Fix :class:`gevent.subprocess.Popen` to not ignore the ``bufsize`` argument. Note
  that this changes the (platform dependent) default, typically from
  buffered to unbuffered. See :pr:`542` by Romuald Brunet.
- Upgraded c-ares to 1.10.0. See :pr:`579` by Omer Katz.

  .. caution:: The c-ares ``configure`` script is now more strict about the
               contents of environment variables such as ``CFLAGS`` and ``LDFLAGS``
               and they may have to be modified (for example, ``CFLAGS`` is no
               longer allowed to include ``-I`` directives, which must instead be
               placed in ``CPPFLAGS``).
- Add a ``count`` argument to :func:`gevent.iwait`. See :pr:`482` by
  wiggin15.
- Add a ``timeout`` argument to :meth:`gevent.queue.JoinableQueue.join`
  which now returns whether all items were waited for or not.
- ``gevent.queue.JoinableQueue`` treats ``items`` passed to
  ``__init__`` as unfinished tasks, the same as if they were ``put``.
  Initial :pr:`554` by DuLLSoN.
- ``gevent.pywsgi`` no longer prints debugging information for the
  normal conditions of a premature client disconnect. See :issue:`136`,
  fixed in :pr:`377` by Paul Collier.
- (Experimental.) Waiting on or getting results from greenlets that
  raised exceptions now usually raises the original traceback. This
  should assist things like Sentry to track the original problem. See
  :issue:`450` and :issue:`528` by Rodolfo and Eddi Linder and
  :issue:`240` by Erik Allik.
- Upgrade to libev 4.20. See :pr:`590` by Peter Renström.
- Fix ``gevent.baseserver.BaseServer`` to be printable when its
  ``handle`` function is an instancemethod of itself. See :pr:`501` by Joe
  Jevnik.
- Make the ``acquire`` method of ``gevent.lock.DummySemaphore`` always
  return True, supporting its use-case as an "infinite" or unbounded
  semaphore providing no exclusion, and allowing the idiom ``if
  sem.acquire(): ...``. See :pr:`544` by Mouad Benchchaoui.
- Patch ``subprocess`` by default in ``gevent.monkey.patch_all``. See
  :issue:`446`.
- ``gevent.pool.Group.imap`` and ``imap_unordered`` now accept
  multiple iterables like ``itertools.imap``. :issue:`565` reported by
  Thomas Steinacher.
- *Compatibility note*: ``gevent.baseserver.BaseServer`` and
  its subclass ``gevent.server.StreamServer`` now deterministically
  close the client socket when the request handler returns.
  Previously, the socket was left at the mercies of the garbage
  collector; under CPython 2.x this meant when the last reference went
  away, which was usually, but not necessarily, when the request
  handler returned, but under PyPy it was some arbitrary point in the
  future and under CPython 3.x a ResourceWarning could be generated.
  This was undocumented behaviour, and the client socket could be kept
  open after the request handler returned either accidentally or intentionally.
- *Compatibility note*: ``pywsgi`` now ensures that headers can be
  encoded in latin-1 (ISO-8859-1). This improves adherence to the HTTP
  standard (and is necessary under Python 3). Under certain
  conditions, previous versions could have allowed non-ISO-8859-1
  headers to be sent, but their interpretation by a conforming
  recipient is unknown; now, a UnicodeError will be raised. See :issue:`614`.


Release 1.0.2
=============

- Fix LifoQueue.peek() to return correct element. :pr:`456`. Patch by Christine Spang.
- Upgrade to libev 4.19
- Remove SSL3 entirely as default TLS protocol
- Import socket on Windows (closes :issue:`459`)
- Fix C90 syntax error (:pr:`449`)
- Add compatibility with Python 2.7.9's SSL changes. :issue:`477`.

Release 1.0.1
=============

- Fix :issue:`423`: Pool's imap/imap_unordered could hang forever. Based on patch and test by Jianfei Wang.


Release 1.0 (Nov 26, 2013)
==========================

- pywsgi: Pass copy of error list instead of direct reference. Thanks to Jonathan Kamens, Matt Iversen.
- Ignore the autogenerated doc/gevent.*.rst files. Patch by Matthias Urlichs.
- Fix cythonpp.py on Windows. Patch by Jeryn Mathew.
- Remove gevent.run (use gevent.wait).


Release 1.0rc3 (Sep 14, 2013)
=============================

- Fix :issue:`251`: crash in gevent.core when accessing destroyed loop.
- Fix :issue:`235`: Replace self._threadpool.close() with self._threadpool.kill() in hub.py. Patch by Jan-Philip Gehrcke.
- Remove unused timeout from select.py (:issue:`254`). Patch by Saúl Ibarra Corretgé.
- Rename Greenlet.link()'s argument to 'callback' (closes :issue:`244`).
- Fix parallel build (:issue:`193`). Patch by Yichao Yu.
- Fix :issue:`263`: potential UnboundLocalError: 'length' in gevent.pywsgi.
- Simplify psycopg2_pool.py (:issue:`239`). Patch by Alex Gaynor.
- pywsgi: allow Content-Length in GET requests (:issue:`264`). Patch by 陈小玉.
- documentation fixes (:issue:`281`) [philipaconrad].
- Fix old documentation about default blocking behavior of kill, killall (:issue:`306`). Patch by Daniel Farina.
- Fix :issue:`6`: patch sys after thread. Patch by Anton Patrushev.
- subprocess: fix check_output on Py2.6 and older (:issue:`265`). Thanks to Marc Sibson for test.
- Fix :issue:`302`: "python -m gevent.monkey" now sets __file__ properly.
- pywsgi: fix logging when bound on unix socket (:issue:`295`). Thanks to Chris Meyers, Eugene Pankov.
- pywsgi: readout request data to prevent ECONNRESET
- Fix :issue:`303`: 'requestline' AttributeError in pywsgi. Thanks to Neil Chintomby.
- Fix :issue:`79`: Properly handle HTTP versions. Patch by Luca Wehrstedt.
- Fix :issue:`216`: propagate errors raised by Pool.map/imap


Release 1.0rc2 (Dec 10, 2012)
=============================

- Fixed :issue:`210`: callbacks were not run for non-default loop (bug introduced in 1.0rc1).
- patch_all() no longer patches subprocess unless `subprocess=True` is passed.
- Fixed AttributeError in hub.Waiter.
- Fixed :issue:`181`: make hidden imports visible to freezing tools like py2exe. Patch by Ralf Schmitt.
- Fixed :issue:`202`: periodically yield when running callbacks (sleep(0) cannot block the event loop now).
- Fixed :issue:`204`: os.tp_read/tp_write did not propogate errors to the caller.
- Fixed :issue:`217`: do not set SO_REUSEADDR on Windows.
- Fixed bug in --module argument for gevent.monkey. Patch by Örjan Persson.
- Remove warning from threadpool.py about mixing fork() and threads.
- Cleaned up hub.py from code that was needed to support older greenlets. Patch by Saúl Ibarra Corretgé.
- Allow for explicit default loop creation via `get_hub(default=True)`. Patch by Jan-Philip Gehrcke.


Release 1.0rc1 (Oct 30, 2012)
=============================

- Fixed hub.switch() not to touch stacktrace when switching. greenlet restores the exception information correctly since version 0.3.2. gevent now requires greenlet >= 0.3.2
- Added gevent.wait() and gevent.iwait(). This is like gevent.joinall() but supports more objects, including Greenlet, Event, Semaphore, Popen. Without arguments it waits for the event loop to finish (previously gevent.run() did that). gevent.run will be removed before final release and gevent.joinall() might be deprecated.
- Reimplemented loop.run_callback with a list and a single prepare watcher; this fixes the order of spawns and improves performance a little.
- Fixes Semaphore/Lock not to init hub in `__init__`, so that it's possible to have module-global locks without initializing the hub. This fixes monkey.patch_all() not to init the hub.
- New implementation of callbacks that executes them in the order they were added. core.loop.callback is removed.
- Fixed 2.5 compatibility.
- Fixed crash on Windows when request 'prev' and 'attr' attributes of 'stat' watcher. The attribute access still fails, but now with an exception.
- Added known_failures.txt that lists all the tests that fail. It can be used by testrunner.py via expected option. It's used when running the test suite in travis.
- Fixed socket, ssl and fileobject to not mask EBADF error - it is now propogated to the caller. Previously EBADF was converted to empty read/write. Thanks to Vitaly Kruglikov
- Removed gevent.event.waitall()
- Renamed FileObjectThreadPool -> FileObjectThread
- Greenlet: Fixed :issue:`143`: greenlet links are now executed in the order they were added
- Synchronize access to FileObjectThread with Semaphore
- EINVAL is no longer handled in fileobject.

monkey:

- Fixed :issue:`178`: disable monkey patch os.read/os.write
- Fixed monkey.patch_thread() to patch threading._DummyThread to avoid leak in threading._active. Original patch by Wil Tan.
- added Event=False argument to patch_all() and patch_thread
- added patch_sys() which patches stdin, stdout, stderr with FileObjectThread wrappers. Experimental / buggy.
- monkey patching everything no longer initializes the hub/event loop.

socket:

- create_connection: do not lookup IPv6 address if IPv6 is unsupported. Patch by Ralf Schmitt.

pywsgi:

- Fixed :issue:`86`: bytearray is now supported. Original patch by Aaron Westendorf.
- Fixed :issue:`116`: Multiline HTTP headers are now handled properly. Patch by Ralf Schmitt.

subprocess:

- Fixed Windows compatibility. The wait() method now also supports 'timeout' argument on Windows.
- Popen: Added rawlink() method, which makes Popen objects supported by gevent.wait(). Updated examples/processes.py
- Fixed :issue:`148`: read from errpipe_read in small chunks, to avoid trigger EINVAL issue on Mac OS X. Patch by Vitaly Kruglikov
- Do os._exit() in "finally" section to avoid executing unrelated code. Patch by Vitaly Kruglikov.

resolver_ares:

- improve getaddrinfo: For string ports (e.g. "http") resolver_ares/getaddrinfo previously only checked either getservbyname(port, "tcp") or getservbyname(port, "udp"), but never both. It now checks both of them.
- gevent.ares.channel now accepts strings as arguments
- upgraded c-ares to cares-1_9_1-12-g805c736
- it is now possible to configure resolver_ares directly with environ, like GEVENTARES_SERVERS

os:

- Renamed threadpool_read/write to tp_read/write.
- Removed posix_read, posix_write.
- Added nb_read, nb_write, make_nonblocking.

hub:

- The system error is now raised immediately in main greenlet in all cases.
- Dropped support for old greenlet versions (need >= 0.3.2 now)

core:

- allow 'callback' property of watcher to be set to None. "del w.callback" no longer works.
- added missing 'noinotify' flag

Misc:

- gevent.thread: allocate_lock is now an alias for LockType/Semaphore. That way it does not fail when being used as class member.
- Updated greentest.py to start timeouts with `ref=False`.
- pool: remove unused get_values() function
- setup.py now recognizes GEVENTSETUP_EV_VERIFY env var which sets EV_VERIFY macro when compiling
- Added a few micro benchmarks
- stdlib tests that we care about are now included in greentest/2.x directories, so we don't depend on them being installed system-wide
- updated util/makedist.py
- the testrunner was completely rewritten.


Release 1.0b4 (Sep 6, 2012)
===========================

- Added gevent.os module with 'read' and 'write' functions. Patch by Geert Jansen.
- Moved gevent.hub.fork to gevent.os module (it is still available as gevent.fork).
- Fixed :issue:`148`: Made fileobject handle EINVAL, which is randomly raised by os.read/os.write on Mac OS X. Thanks to Mark Hingston.
- Fixed :issue:`150`: gevent.fileobject.SocketAdapter.sendall() could needlessly wait for write event on the descriptor. Original patch by Mark Hingston.
- Fixed AttributeError in baseserver. In case of error, start() would call kill() which was renamed to close(). Thanks to Vitaly Kruglikov.


Release 1.0b3 (Jul 27, 2012)
============================

- New gevent.subprocess module
- New gevent.fileobject module
- Fixed ThreadPool to discard references of the objects passed to it (function, arguments) asap. Previously they could be stored for unlimited time until the thread gets a new job.
- Fixed :issue:`138`: gevent.pool.Pool().imap_unordered hangs with an empty iterator. Thanks to exproxus.
- Fixed :issue:`127`: ssl.py could raise TypeError in certain cases. Thanks to Johan Mjones.
- Fixed socket.makefile() to keep the timeout setting of the socket instance. Thanks to Colin Marc.
- Added 'copy()' method to queues.
- The 'nochild' event loop config option is removed. The install_sigchld offer more flexible way of enabling child watchers.
- core: all watchers except for 'child' now accept new 'priority' keyword argument
- gevent.Timeout accepts new arguments: 'ref' and 'priority'. The default priority for Timeout is -1.
- Hub.wait() uses Waiter now instead of raw switching
- Updated libev to the latest CVS version
- Made pywsgi to raise an AssertionError if non-zero content-length is passed to start_response(204/304) or if non-empty body is attempted to be written for 304/204 response
- Removed pywsgi feature to capitalize the passed headers.
- Fixed util/cythonpp.py to work on python3.2 (:issue:`123`). Patch by Alexandre Kandalintsev.
- Added 'closed' readonly property to socket.
- Added 'ref' read/write property to socket.
- setup.py now parses CARES_EMBED and LIBEV_EMBED parameters, in addition to EMBED.
- gevent.reinit() and gevent.fork() only reinit hub if it was created and do not create it themselves
- Fixed setup.py not to add libev and c-ares to include dirs in non-embed mode. Patch by Ralf Schmitt.
- Renamed util/make_dist.py to util/makedist.py
- testrunner.py now saves more information about the system; the stat printing functionality is moved to a separate util/stat.py script.


Release 1.0b2 (Apr 11, 2012)
============================

Major and backward-incompatible changes:

- Made the threadpool-based resolver the default. To enable the ares-based resolver, set GEVENT_RESOLVER=ares env var.
- Added support for child watchers (not available on Windows).
  - Libev loop now reaps all children by default.
  - If NOCHILD flag is passed to the loop, child watchers and child reaping are disabled.
- Renamed gevent.coros to gevent.lock. The gevent.coros is still available but deprecated.
- Added 'stat' watchers to loop.
- The setup.py now recognizes gevent_embed env var. When set to "no", bundled c-ares and libev are ignored.
- Added optional 'ref' argument to sleep(). When ref=false, the watchers created by sleep() do not hold gevent.run() from exiting.
- ThreadPool now calls Hub.handle_error for exceptions in worker threads.
- ThreadPool got new method: apply_e.
- Added new extension module gevent._util and moved gevent.core.set_exc_info function there.
- Added new extension module gevent._semaphore. It contains Semaphore class which is imported by gevent.lock as gevent.lock.Semaphore. Providing Semaphore in extension module ensures that trace function set with settrace will not be called during __exit__. Thanks to Ralf Schmitt.
- It is now possible to kill or pre-spawn threads in ThreadPool by setting its 'size' property.

core:

- Make sure the default loop cannot be destroyed more than once, thus crashing the process.
- Make Hub.destroy() method not to destroy the default loop, unless *destroy_loop* is *True*. Non-default loops are still destroyed by default.
- loop: Removed properties from loop: fdchangecnt, timercnt, asynccnt.
- loop: Added properties: sigfd, origflags, origflags_int
- loop: The EVFLAG_NOENV is now always passed to libev. Thus LIBEV_FLAGS env variable is no longer checked. Use GEVENT_BACKEND.

Misc:

- Check that the argument of link() is callable. Raise TypeError when it's not.
- Fixed TypeError in baseserver when parsing an address.
- Pool: made add() and discard() usable by external users. Thanks to Danil Eremeev.
- When specifying a class to import, it is now possible to use format path/package.module.name
- pywsgi: Made sure format_request() does not fail if 'status' attribute is not set yet
- pywsgi: Added REMOTE_PORT variable to the environment.

Examples:

- portforwarder.py now shows how to use gevent.run() to implement graceful shutdown of a server.
- psycopg2_pool.py: Changed execute() to return rowcount.
- psycopg2_pool.py: Added fetchall() and fetchiter() methods.

Developer utilities:

- When building, CYTHON env variable can be used to specify Cython executable to use.
- util/make_dist.py now recongizes --fast and --revert options. Previous --rsync option is removed.
- Added util/winvbox.py which automates building/testing/making binaries on Windows VM.
- Fixed typos in exception handling code in testrunner.py
- Fixed patching unittest.runner on Python2.7. This caused the details of test cases run lost.
- Made testrunner.py kill the whole process group after test is done.


Release 1.0b1 (Jan 10, 2012)
============================

Backward-incompatible changes:

- Removed "link to greenlet" feature of Greenlet.
- If greenlet module older than 0.3.2 is used, then greenlet.GreenletExit.__bases__ is monkey patched to derive from BaseException and not Exception. That way gevent.GreenletExit is always derived from BaseException, regardless of installed greenlet version.
- Some code supporting Python 2.4 has been removed.

Release highlights:

- Added thread pool: gevent.threadpool.ThreadPool.
- Added thread pool-based resolver. Enable with GEVENT_RESOLVER=thread.
- Added UDP server: gevent.server.DatagramServer
- A "configure" is now run on libev. This fixes a problem of 'kqueue' not being available on Mac OS X.
- Gevent recognizes some environment variables now:
  - GEVENT_BACKEND allows passing argument to loop, e.g. "GEVENT_BACKEND=select" for force select backend
  - GEVENT_RESOLVER allows choosing resolver class.
  - GEVENT_THREADPOOL allows choosing thread pool class.
- Added new examples: portforwarder, psycopg2_pool.py, threadpool.py, udp_server.py
- Fixed non-embedding build. To build against system libev, remove or rename 'libev' directory. To build against system c-ares, remove or rename 'c-ares'. Thanks to Örjan Persson.

misc:
- gevent.joinall() method now accepts optional 'count' keyword.
- gevent.fork() only calls reinit() in the child process now.
- gevent.run() now returns False when exiting because of timeout or event (previous None).
- Hub got a new method: destroy().
- Hub got a new property: threadpool.

ares.pyx:
- Fixed :issue:`104`: made ares_host_result pickable. Thanks to Shaun Cutts.

pywsgi:
- Removed unused deprecated 'wfile' property from WSGIHandler
- Fixed :issue:`92`: raise IOError on truncated POST requests.
- Fixed :issue:`93`: do not sent multiple "100 continue" responses

core:
- Fixed :issue:`97`: the timer watcher now calls ev_now_update() in start() and again() unless 'update' keyword is passed and set to False.
- add set_syserr_cb() function; it's used by gevent internally.
- gevent now installs syserr callback using libev's set_syserr_cb. This callback is called when libev encounters an error it cannot recover from. The default action is to print a message and abort. With the callback installed, a SystemError() is now raised in the main greenlet.
- renamed 'backend_fd' property to 'fileno()' method. (not available if you build gevent against system libev)
- added 'asynccnt' property (not available if you build gevent against system libev)
- made loop.__repr__ output a bit more compact
- the watchers check the arguments for validness now (previously invalid argument would crash libev).
- The 'async' watcher now has send() method;
- fixed time() function
- libev has been upgraded to latest CVS version.
- libev has been patched to use send()/recv() for evpipe on windows when libev_vfd.h is in effect

resolver_ares:
- Slightly improved compatibility with stdlib's socket in some error cases.

socket:
- Fixed close() method not to reference any globals
- Fixed :issue:`115`: _dummy gets unexpected Timeout arg
- Removed _fileobject used for python 2.4 compatibility in socket.py
- Fixed :issue:`94`: fallback to buffer if memoryview fails in _get_memory on python 2.7

monkey:
- Removed patch_httplib()
- Fixed :issue:`112`: threading._sleep is not patched. Thanks to David LaBissoniere.
- Added get_unpatched() function. However, it is slightly broken at the moment.

backdoor:
- make 'locals()' not spew out __builtin__.__dict__ in backdoor
- add optional banner argument to BackdoorServer

servers:
- add server.DatagramServer;
- StreamServer: 'ssl_enabled' is now a read-only property
- servers no longer have 'kill' method; it has been renamed to 'close'.
- listeners can now be configured as strings, e.g. ':80' or 80
- modify baseserver.BaseServer in such a way that makes it a good base class for both StreamServer and DatagramServer
- BaseServer no longer accepts 'backlog' parameter. It is now done by StreamServer.
- BaseServer implements start_accepting() and stop_accepting() methods
- BaseServer now implements "temporarily stop accepting" strategy
- BaseServer now has _do_read method which does everything except for actually calling accept()/recvfrom()
- pre_start() method is renamed to init_socket()
- renamed _stopped_event to _stop_event
- 'started' is now a read-only property (which actually reports state of _stop_event)
- post_stop() method is removed
- close() now sets _stop_event(), thus setting 'started' to False, thus causing serve_forever() to exit
- _tcp_listener() function is moved from baseserver.py to server.py
- added 'fatal_errors' class attribute which is a tuple of all errnos that should kill the server

coros:
- Semaphore: add _start_notify() method
- Semaphore: avoid copying list of links; rawlink() no longer schedules notification



Release 1.0a3 (Sep 15, 2011)
============================

Added 'ref' property to all watchers. Settings it to False make watcher call ev_unref/ev_ref appropriately so that this watcher does not prevent loop.run()/hub.join()/run() from exiting.
Made resolver_ares.Resolver use 'ref' property for internal watcher.

In all servers, method "kill" was renamed to "close". The old name is available as deprecated alias.

Added a few properties to the loop: backend_fd, fdchangecnt, timercnt.

Upgraded c-ares to 1.7.5+patch.

Fixed getaddrinfo to return results in the order (::1, IPv4, IPv6).

Fixed getaddrinfo() to handle integer of string type. Thanks to kconor.

Fixed gethostbyname() to handle '' (empty string).

Fixed getaddrinfo() to convert UnicodeEncodeError into error('Int or String expected').

Fixed getaddrinfo() to uses the lowest 16 bits of passed port integer similar to built-in _socket.

Fixed getnameinfo() to call getaddrinfo() to process arguments similar to built-in _socket.

Fixed gethostbyaddr() to use getaddrinfo() to process arguments.

version_info is now a 5-tuple.

Added handle_system_error() method to Hub (used internally).

Fixed Hub's run() method to never exit. This prevent inappropriate switches into parent greenlet.

Fixed Hub.join() to return True if Hub was already dead.

Added 'event' argument to Hub.join().

Added `run()` function to gevent top level package.

Fixed Greenlet.start() to exit silently if greenlet was already started rather than raising :exc:`AssertionError`.

Fixed Greenlet.start() not to schedule another switch if greenlet is already dead.

Fixed gevent.signal() to spawn Greenlet instead of raw greenlet. Also it'll switch into the new greenlet immediately instead of scheduling additional callback.

Do monkey patch create_connection() as gevent's version works better with gevent.socket.socket than the standard create_connection.

pywsgi: make sure we don't try to read more requests if socket operation failed with EPIPE

pywsgi: if we failed to send the reply, change 'status' to socket error so that the logs mention the error.


Release 1.0a2 (Aug 2, 2011)
===========================

Fixed a bug in gevent.queue.Channel class. (Thanks to Alexey Borzenkov)


Release 1.0a1 (Aug 2, 2011)
===========================

Backward-incompatible changes:

- Dropped support for Python 2.4.
- `Queue(0)` is now equivalent to an unbound queue and raises :exc:`DeprecationError`. Use :class:`gevent.queue.Channel` if you need a channel.
- Deprecated ability to pass a greenlet instance to :meth:`Greenlet.link`, :meth:`Greenlet.link_value` and :meth:`Greenlet.link_exception`.
- All of :mod:`gevent.core` has been rewritten and the interface is not compatible.
- :exc:`SystemExit` and :exc:`SystemError` now kill the whole process instead of printing a traceback.
- Removed deprecated :class:`util.lazy_property` property.
- Removed :mod:`gevent.dns` module.
- Removed deprecated gevent.sslold module
- Removed deprecated gevent.rawgreenlet module
- Removed deprecated name `GreenletSet` which used to be alias for :class:`Group`.

Release highlights:

- The :mod:`gevent.core` module now wraps libev's API and is not compatible with gevent 0.x.
- Added a concept of pluggable event loops. By default gevent.core.loop is used, which is a wrapper around libev.
- Added a concept of pluggable name resolvers. By default a resolver based on c-ares library is used.
- Added support for multiple OS threads, each new thread will get its own Hub instance with its own event loop.
- The release now includes and embeds the dependencies: libev and c-ares.
- The standard :mod:`signal` works now as expected.
- The unhandled errors are now handled uniformely by `Hub.handle_error` function.
- Added :class:`Channel` class to :mod:`gevent.queue` module. It is equivalent to `Queue(0)` in gevent 0.x, which is deprecated now.
- Added method :meth:`peek` to :class:`Queue` class.
- Added :func:`idle` function which blocks until the event loop is idle.
- Added a way to gracefully shutdown the application by waiting for all outstanding greenlets/servers/watchers: :meth:`Hub.join`.
- Added new :mod:`gevent.ares` C extension which wraps `c-ares` and provides asynchronous DNS resolver.
- Added new :mod:`gevent.resolver_ares` module provides synchronous API on top of :mod:`gevent.ares`.

The :mod:`gevent.socket` module:

- DNS functions now use c-ares library rather than libevent-dns. This
  fixes a number of problems with name resolving:

  - Fix :issue:`2`: DNS resolver no longer breaks after `fork()`. You still need to call :func:`gevent.fork` (`os.fork` is monkey
     patched with it if `monkey.patch_all()` was called).
  - DNS resolver no longer ignores `/etc/resolv.conf` and `/etc/hosts`.

- The following functions were added to socket module
  - gethostbyname_ex
  - getnameinfo
  - gethostbyaddr
  - getfqdn

- Removed undocumented bind_and_listen and tcp_listener

The :class:`Hub` object:

- Added :meth:`join` method which waits until the event loop exits or optional timeout expires.
- Added :meth:`wait` method which waits until a watcher has got an event.
- Added :meth:`handle_error` method which is called by all of gevent in case of unhandled exception.
- Added :meth:`print_exception` method which is called by `handle_error` to print the exception traceback.

The :class:`Greenlet` objects:

- Added `__nonzero__` implementation that returns `True` after greenlet was started until it's dead.
  Previously greenlet was `False` after `start()` until it was first switched to.

The mod:`gevent.pool` module:

- It is now possible to add raw greenlets to the pool.
- The :meth:`map` and :meth:`imap` methods now start yielding the results as soon as possible.
- The :meth:`imap_unordered` no longer swallows an exception raised while iterating its argument.

Miscellaneous:

- `gevent.sleep(<negative value>)` no longer raises an exception, instead it does `sleep(0)`.
- Added method `clear` to internal `Waiter` class.
- Removed `wait` method from internal `Waiter` class.
- The :class:`WSGIServer` now sets `max_accept` to 1 if `wsgi.multiprocessing` is set to `True`.
- Added :func:`monkey.patch_module` function that monkey patches module using `__implements__` list provided by gevent module.
  All of gevent modules that replace stdlib module now have `__implements__` attribute.


Release 0.13.8 (September 6, 2012)
==================================

- Fixed :issue:`80`: gevent.httplib failed with RequestFailed errors because timeout was reset to 1s. Patch by Tomasz Prus.
- core: fix compilation with the latest Cython: remove emit_ifdef/emit_else/emit_endif.
- Fixed :issue:`132`: gevent.socket.gethostbyname(<unicode>) now does ascii encoding and uses gevent's resolver rather than calling built-in resolver. Patch by Alexey Borzenkov.


Release 0.13.7 (April 12, 2012)
===============================

- Fixed :issue:`94`: fallback to buffer if memoryview fails in _get_memory on python 2.7.
- Fixed :issue:`103`: ``Queue(None).full()`` returns ``False`` now (previously it returned ``True``).
- Fixed :issue:`112`: threading._sleep is not patched. Thanks to David LaBissoniere.
- Fixed :issue:`115`: _dummy gets unexpected Timeout arg.


Release 0.13.6 (May 2, 2011)
============================

- Added ``__copy__`` method to :class:`gevent.local.local` class that implements copy semantics compatible with built-in ``threading.local``. Patch by **Galfy Pundee**.
- Fixed :class:`StreamServer` class to catch ``EWOULDBLOCK`` rather than ``EAGAIN``. This fixes lots of spurious tracebacks on Windows where these two constants are not the same. Patch by **Alexey Borzenkov**.
- Fixed :issue:`65`: :func:`fork` now calls ``event_reinit`` only in the child process; otherwise the process could hang when using libevent2. Patch by **Alexander Boudkar**.


Release 0.13.5 (Apr 21, 2011)
=============================

- Fixed build problem on Python 2.5


Release 0.13.4 (Apr 11, 2011)
=============================

- Fixed :exc:`TypeError` that occurred when ``environ["wsgi.input"].read`` function was called with an integer argument.
- Fixed :issue:`63`: :func:`monkey.patch_thread` now patches :mod:`threading` too, even if it's already imported. Patch by **Shaun Lindsay**.
- Fixed :issue:`64`: :func:`joinall` and :func:`killall` functions used to hang if their argument contained duplicate greenlets.
- Fixed :issue:`69`: :class:`pywsgi.WSGIServer` reported "Connection reset by peer" if the client did not close the connection gracefully after the last request. Such errors are now ignored.
- Fixed :issue:`67`: Made :class:`wsgi.WSGIServer` add ``REQUEST_URI`` to environ. Patch by **Andreas Blixt**.
- Fixed :issue:`71`: monkey patching ``httplib`` with :mod:`gevent.httplib` used to break ``HTTPSConnection``. Patch by **Nick Barkas**.
- Fixed :issue:`74`: :func:`create_connection <gevent.socket.create_connection>` now raises proper exception when ``getaddrinfo`` fails.
- Fixed :meth:`BaseServer.__repr__` method, :attr:`BaseServer.server_host` and :attr:`BaseServer.server_port` attributes to handle the case of ``AF_UNIX`` addresses properly. Previously they assumed address is always a tuple.
- Fixed :class:`pywsgi.WSGIServer` to handle ``AF_UNIX`` listeners. The server now sets ``environ["SERVER_NAME"]`` and ``environ["SERVER_PORT"]`` to empty string in such case.
- Make :class:`StreamServer` (and thus :class:`pywsgi.WSGIServer`) accept up to 100 connections per one readiness notification. This behaviour is controlled by :attr:`StreamServer.max_accept` class attribute.
- If bind fails, the servers now include the address that caused bind to fail in the error message.


Release 0.13.3 (Feb 7, 2011)
============================

- Fixed typo in :mod:`gevent.httplib` that rendered it unusable.
- Removed unnecessary delay in :func:`getaddrinfo <gevent.socket.getaddrinfo>` by calling ``resolve_ipv4`` and ``resolve_ipv6`` concurrently rather than sequentially in ``AF_UNSPEC`` case.


Release 0.13.2 (Jan 28, 2011)
=============================

- Added :mod:`gevent.httplib` -- **experimental** support for libevent-http client (:issue:`9`). Thanks to **Tommie Gannert**, **Örjan Persson**.
- Fixed crash on Mac OS X (:issue:`31`). Patch by **Alexey Borzenkov**.
- Fixed compatiblity of :mod:`gevent.wsgi` with libevent2 (:issue:`62`).
- Fixed compilation issues with libevent2. Patch by **Ralf Schmitt**.
- Fixed :mod:`pywsgi` not to use chunked transfer encoding in case of 304 and 204 responses as it creates a non-empty message body which is against RFC and causes some browsers to fail. Patch by **Nicholas Piël**.
- Fixed :func:`socket.getaddrinfo` to handle ``AF_UNSPEC`` properly and resolve service names (:issue:`56`). Thanks to **Elizabeth Jennifer Myers**.
- Fixed :func:`socket.getaddrinfo` to handle international domain names.
- Fixed leaking of traceback object when switching out of greenlet with ``sys.exc_info`` set. Leaking is prevented by not preserving traceback at all and only keeping the value of the exception. Thanks to **Ned Rockson**.
- Fixed :meth:`ssl.SSLSocket.unwrap` to shutdown :class:`SSLSocket` properly, without raising ``SSLError(read operation timeout)``.
- Fixed :exc:`TypeError` inside :class:`Hub` on Python 2.4.
- Made a number of internal improvements to :mod:`gevent.pywsgi` to make subclassing easier.
- Changed :class:`WSGIServer <pywsgi.WSGIServer>` to explicitly close the socket after the last request. Patch by **Ralf Schmitt**.
- Fixed :class:`pywsgi.WSGIHandler` not to add ``CONTENT_TYPE`` to the *environ* dict when there's no ``Content-Type`` header in the request. Previously a default ``text/plain`` was added in such case.
- Added proper implementation of :meth:`imap_unordered <gevent.pool.Group.imap_unordered>` to :class:`Pool` class. Unlike previous "dummy" implementation this one starts yielding the results as soon as they are ready.
- Implemented iterator protocol in :class:`Queue <gevent.queue.Queue>`. The main use case is the implementation of :meth:`Pool.imap_unordered`.
- Fixed :attr:`BaseServer.started` property: it is now set to ``True`` after :meth:`start <StreamServer.start>` until :meth:`stop <StreamServer.stop>` or :meth:`kill <StreamServer.kill>`. Previously it could become ``False`` for short period of times, because :class:`StreamServer` could stop accepting for a while in presence of errors and :attr:`StreamServer.started` was defined as "whether the server is currently accepting".
- Fixed :class:`wsgi.WSGIServer` to reply with 500 error immediately if the application raises an error (:issue:`58`). Thanks to **Jon Aslund**.
- Added :func:`monkey.patch_httplib` function which is disabled by default.
- Added *httplib* parameter to :func:`monkey.patch_all` (defaults to ``False``).
- Added :func:`write <core.buffer.write>` method to :class:`core.buffer`.
- Fixed :exc:`OverflowError` that could happen in :meth:`core.event.__str__`.
- Made :meth:`http_request.get_input_headers` return header names in lower case.
- Fixed :class:`StreamServer` to accept *ciphers* as an SSL argument.
- Added ``build_exc --cython=`` option to ``setup.py``. Patch by **Ralf Schmitt**.
- Updated :class:`local <gevent.local.local>` to raise :exc:`AttributeError` if ``__dict__`` attribute is set or deleted.


Release 0.13.1 (Sep 23, 2010)
=============================

Release highlights:

- Fixed :mod:`monkey` to patch :func:`socket.create_connection <gevent.socket.create_connection>`.
- Updated :mod:`gevent.ssl` module to fully match the functionality of :mod:`ssl` on Python 2.7.
- Fixed :meth:`Group.join` to handle ``raise_error=True`` properly, it used to raise :exc:`TypeError` (:issue:`36`). Thanks to by **David Hain**.
- Fixed :mod:`gevent.wsgi` and :mod:`gevent.pywsgi` to join multiple ``Cookie`` headers (:issue:`40`).
- Fixed :func:`select <gevent.select.select>` to recognize ``long`` arguments in addition to ``int``.
- Fixed :meth:`Semaphore.acquire` to return ``False`` when timeout expires instead of raising :exc:`AssertionError` (:issue:`39`). Patch by **Erik Näslund**.
- Fixed :meth:`JoinableQueue.join` to return immediately if queue is already empty (:issue:`45`). Patch by **Dmitry Chechik**.
- Deprecated :mod:`gevent.sslold` module.

:mod:`gevent.socket` module:

- Overrode :meth:`socket.shutdown` method to interrupt read/write operations on socket.
- Fixed possible :exc:`NameError` in :meth:`socket.connect_ex` method. Patch by **Alexey Borzenkov**.
- Fixed socket leak in :func:`create_connection` function.
- Made :mod:`gevent.socket` import all public items from stdlib :mod:`socket` that do not do I/O.

:mod:`gevent.ssl` module:

- Imported a number of patches from stdlib by **Antoine Pitrou**:

  - Calling :meth:`makefile` method on an SSL object would prevent the underlying socket from being closed until all objects get truly destroyed (Python issue #5238).
  - SSL handshake would ignore the socket timeout and block indefinitely if the other end didn't respond (Python issue #5103).
  - When calling :meth:`getpeername` in ``SSLSocket.__init__``, only silence exceptions caused by the "socket not connected" condition.

- Added support for *ciphers* argument.
- Updated ``SSLSocket.send`` and ``SSLSocket.recv`` methods to match the behavior of stdlib :mod:`ssl` better.
- Fixed :class:`ssl.SSLObject` to delete events used by other greenlets when closing the instance (:issue:`34`).

Miscellaneous:

- Made :class:`BaseServer` accept ``long`` values as *pool* argument in addition to ``int``.
- Made :attr:`http._requests` attribute public.
- Updated webchat example to use file on disk rather than in-memory sqlite database to avoid :exc:`OperationalError`.
- Fixed ``webproxy.py`` example to be runnable under external WSGI server.
- Fixed bogus failure in ``test__exc_info.py``.
- Added new test to check PEP8 conformance: ``xtest_pep8.py``.
- Fixed :class:`BackdoorServer` close the connection on :exc:`SystemExit` and simplified the code.
- Made :class:`Pool` raise :exc:`ValueError` when initialized with ``size=0``.
- Updated ``setup.py --libevent`` to configure and make libevent if it's not built already.
- Updated ``setup.py`` to use ``setuptools`` if present and add dependency on ``greenlet``.
- Fixed doc/mysphinxext.py to work with Sphinx 1. Thanks by **Örjan Persson**.


Release 0.13.0 (Jul 14, 2010)
=============================

Release highlights:

- Added :mod:`gevent.server` module with :class:`StreamServer` class for easy implementing of TCP and SSL servers.
- Added :mod:`gevent.baseserver` module with :class:`BaseServer` class.
- Added new implementation of :mod:`gevent.pywsgi` based on :mod:`gevent.server`. Contributed by **Ralf Schmitt**.
- Added :mod:`gevent.local` module. Fixed :issue:`24`. Thanks to **Ted Suzman**.
- Fixed a number of bugs in :mod:`gevent.wsgi` module.
- Fixed :issue:`26`: closing a socket now interrupts all pending read/write operations on it.
- Implemented workaround that prevents greenlets from leaking ``exc_info``.
- Fixed :meth:`socket.sendall` to use buffer object to prevent string copies.
- Made the interfaces of :mod:`gevent.wsgi` and :mod:`gevent.pywsgi` much more similar to each other.
- Fixed compilation on Windows with libevent-2.
- Improved Windows compatibility. Fixed :issue:`30`. Thanks to **Luigi Pugnetti**.
- Fixed compatibility with Python 2.7.

Backward-incompatible changes:

- Blocking is now the default behaviour for the :meth:`Greenlet.kill` method and other kill* methods.
- Changed the inteface of :class:`http.HTTPServer` to match the interface of other servers.
- Changed :class:`Pool`'s :meth:`spawn` method to block until there's a free slot.
- Removed deprecated :func:`backdoor.backdoor_server` function.
- Removed deprecated functions in :mod:`socket` module:

  - :func:`socket_bind_and_listen`
  - :func:`set_reuse_addr`
  - :func:`connect_tcp`
  - :func:`tcp_server`

- Removed deprecated :attr:`socket.fd` property.
- Deprecated use of negative numbers to indicate infinite timeout in :func:`core.event.add` and :func:`socket.wait_read` and similar. Use ``None`` from now on, which is compatible with the previous versions.
- Derived :class:`backdoor.BackdoorServer` from :class:`StreamServer` rather than from :class:`Greenlet`. This adds lots of new features and removes a few old ones.
- Removed non-standard :attr:`balance` property from :class:`Semaphore`.
- Removed :func:`start`, :func:`set_cb` and :func:`set_gencb` from :class:`core.http`.
- Removed :func:`set_closecb` from :class:`core.http_connection`. It is now used internally to detach the requests of the closed connections.
- Deprecated :mod:`rawgreenlet` module.
- Deprecated :func:`util.lazy_property`.
- Renamed :class:`GreenletSet` to :class:`Group`. The old name is currently available as an alias.

:mod:`gevent.socket` module:

- Fixed issues :issue:`26` and :issue:`34`: closing the socket while reading/writing/connecting is now safe. Thanks to **Cyril Bay**.
- Imported :func:`getfqdn` from :mod:`socket` module.
- The module now uses ``sys.platform`` to detect Windows rather than :mod:`platform` module.
- Fixed :issue:`27`: :func:`getaddrinfo` used to handle the case when *socktype* or *proto* were equal to ``0``. Thanks to **Randall Leeds**.

:mod:`gevent.coros` module:

- Added :class:`RLock` class.
- Added :class:`DummySemaphore` class.
- Fixed :class:`BoundedSemaphore` class to behave like :class:`threading.BoundedSemaphore` behaves.

:mod:`gevent.event` module:

- Made :meth:`Event.wait` return internal flag instead of ``None``.
- Made :meth:`AsyncResult.wait` return its ``value`` instead of ``None``.
- Added :meth:`ready` method as an alias for :meth:`is_set`.

:mod:`gevent.wsgi` module:

- Removed :class:`wsgi.buffer_proxy`.

:mod:`gevent.pywsgi` module:

- Rewritten to use :mod:`server` and not to depend on :mod:`BaseHTTPServer`.
- Changed the interface to match :mod:`wsgi` module.
  Removed :func:`server` function, add :class:`Server` class, added :class:`WSGIServer` class.
- Renamed :class:`HttpProtocol` to :class:`WSGIHandler`.
- Fixed compatibility with webob by allowing an optional argument to :meth:`readline`.

:mod:`gevent.core` module:

- Fixed reference leaks in :class:`event` class.
- Avoid Python name lookups when accessing EV_* constants from Cython code. Patch by **Daniele Varrazzo**.
- Added *persist* argument to :class:`read_event`, :class:`write_event` and :class:`readwrite_event`.
- Made all of the event loop callbacks clear the exception info before exiting.
- Added :attr:`flags_str` property to :class:`event`. It is used by ``__str__`` and ``__repr__``.
- :class:`buffer <core.buffer>`:

  - Added :meth:`detach` method.
  - Implemented iterator protocol.
  - Fixed :meth:`readline` and :meth:`readlines` methods.

- :class:`http_request`:

  - Fixed :meth:`detach` to detach input and output buffers too.
  - Changed the response to send 500 error upon deallocation, if no response was sent by the user.
  - Made :attr:`input_buffer` and :attr:`output_buffer` store and reuse the :class:`buffer` object they create.
  - Fixed :meth:`__str__` and meth:`__repr__` to include spaces where needed.
  - :class:`http` class no longer has :meth:`set_cb` and :meth:`set_gencb`. Instead its contructor accepts *handle* which will be called on each request.

:mod:`gevent.http` and :mod:`gevent.wsgi` modules:

- Made :class:`HTTPServer` use ``"Connection: close"`` header by default.
- Class :class:`HTTPServer` now derives from :class:`baseserver.BaseServer`. Thus its :meth:`start` method no longer accepts socket to listen on, it must be passed to the contructor.
- The *spawn* argument now accepts a :class:`Pool` instance. While the pool is full, the server replies with 503 error.
- The server no longer links to the greenlets it spawns to detect errors. Instead, it relies on :class:`http_request` which will send 500 reply when deallocated if the user hasn't send any.

Miscellaneous:

- Changed :mod:`gevent.thread` to use :class:`Greenlet` instead of raw greenlets. This means monkey patched thread will become :class:`Greenlet` too.
- Added :attr:`started` property to :class:`Greenlet`.
- Put common server code in :mod:`gevent.baseserver` module. All servers in gevent package are now derived from :class:`BaseServer`.
- Fixed :issue:`20`: :func:`sleep` now raises :exc:`IOError` if passed a negative argument.
- Remove the code related to finding out libevent version from setup.py as macro ``USE_LIBEVENT_?`` is no longer needed to build ``gevent.core``.
- Increased default backlog in all servers (from 5 to 256). Thanks to **Nicholas Piël**.
- Fixed doc/conf.py to work in Python older than 2.6. Thanks to **Örjan Persson**.
- Silenced SystemError raised in :mod:`backdoor` when a client typed ``quit()``.
- If importing :mod:`greenlet` failed with ImportError, keep the original error message,
  because sometimes the error originates in setuptools.
- Changed :func:`select.select` to return all the file descriptors signalled, not just the first one.
- Made :mod:`thread` (and thus monkey patched threads) to spawn :class:`Greenlet` instances, rather than raw greenlets.

Examples:

- Updated echoserver.py to use :class:`StreamServer`.
- Added geventsendfile.py.
- Added wsgiserver_ssl.py.

Thanks to **Ralf Schmitt** for :mod:`pywsgi`, a number of fixes for :mod:`wsgi`, help with
:mod:`baseserver` and :mod:`server` modules, improving setup.py and various other patches and suggestions.

Thanks to **Uriel Katz** for :mod:`pywsgi` patches.


Release 0.12.2 (Mar 2, 2010)
============================

* Fixed http server to put the listening socket into a non-blocking mode. Contributed by **Ralf Schmitt**.


Release 0.12.1 (Feb 26, 2010)
=============================

* Removed a symlink from the distribution (that causes pip to fail). Thanks to **Brad Clements** for reporting it.
* setup.py: automatically create symlink from ``build/lib.../gevent/core.so`` to ``gevent/core.so``.
* :mod:`gevent.socket`: Improved compatibility with stdlib's socket:

  - Fixed :class:`socket <gevent.socket.socket>` to raise ``timeout("timed out")`` rather than simply ``timeout``.
  - Imported ``_GLOBAL_DEFAULT_TIMEOUT`` from standard :mod:`socket` module instead of creating a new object.


Release 0.12.0 (Feb 5, 2010)
============================

Release highlights:

- Added :mod:`gevent.ssl` module.
- Fixed Windows compatibility (experimental).
- Improved performance of :meth:`socket.recv`, :meth:`socket.send` and similar methods.
- Added a new module - :mod:`dns` - with synchronous wrappers around libevent's DNS API.
- Added :class:`core.readwrite_event` and :func:`socket.wait_readwrite` functions.
- Fixed several incompatibilities of :mod:`wsgi` module with the WSGI spec.
- Deprecated :mod:`pywsgi` module.

:mod:`gevent.wsgi` module:

- Made ``env["REMOTE_PORT"]`` into a string.
- Fixed the server to close the iterator returned by the application.
- Made ``wsgi.input`` object iterable.

:mod:`gevent.core` module:

- Made DNS functions no longer accept/return IP addresses in dots-and-numbers format. They work
  with packed IPs now.
- Made DNS functions no longer accept additional arguments to pass to the callback.
- Fixed DNS functions to check the return value of the libevent functions and raise
  :exc:`IOError` if they failed.
- Added :func:`core.dns_err_to_string`.
- Made core.event.cancel not to raise if event_del reports an error. instead, the return code is
  passed to the caller.
- Fixed minor issue in string representation of the events.

:mod:`gevent.socket` module:

- Fixed bug in socket.accept. It could return unwrapped socket instance if socket's timeout is 0.
- Fixed socket.sendall implementation never to call underlying socket's sendall.
- Fixed :func:`gethostbyname` and :func:`getaddrinfo` to call the stdlib if the passed hostname has no dots.
- Fixed :func:`getaddrinfo` to filter the results using *socktype* and *proto* arguments.
- Removed :func:`getnameinfo` as it didn't quite match the stdlib interface.
  Use :func:`dns.resolve_reverse` for reverse resolutions.
- Fixed :meth:`socket.connect_ex` to use cooperative :func:`gethostbyname`.
- Fixed :meth:`socket.dup` not to call underlying socket's :meth:`dup` (which is not available
  on Windows) but to use Python's reference counting similar to how the stdlib's socket
  implements :meth:`dup`
- Added *_sock* argument to :class:`socket`'s constructor. Passing the socket instance
  as first argument is no longer supported.
- Fixed :func:`socket.connect` to ignore ``WSAEINVAL`` on Windows.
- Fixed :func:`socket.connect` to use :func:`wait_readwrite` instead of :func:`wait_write`.
- Fixed :func:`socket.connect` to consult ``SO_ERROR``.
- Fixed :func:`socket.send` and :func:`socket.sendall` to support *flags* argument.
- Renamed :func:`socket_bind_and_listen` to :func:`socket.bind_and_listen`. The old name
  is still available as a deprecated alias.
- The underlying socket object is now stored as ``_sock`` property.
- Imported the constants and some utility functions from stdlib's :mod:`socket` into :mod:`gevent.socket`.
  (Thanks to **Matt Goodall** for the original patch).
- Renamed :meth:`wrap_ssl` to :meth:`ssl`. (the old name is still available but deprecated)
- Deprecated :func:`connect_tcp` and :func:`tcp_server`.
- Added :exc:`sslerror` to ``socket.__all__``.
- Removed :class:`GreenSocket` alias for socket class.
- Moved PyOpenSSL-based implementation of :func:`socket.ssl` into :mod:`gevent.oldssl` module.
  It's imported into :mod:`gevent.socket` if importing :mod:`gevent.ssl` fails.

Miscellaneous:

- Fixed Greenlet.spawn_link* and GreenletSet.spawn_link* classmethods not to assume anything
  about their arguments. (Thanks to **Marcus Cavanaugh** for pointing that out).
- Fixed :func:`select <gevent.select.select>` to clean up properly if event creation fails.
- Fixed :func:`select <gevent.select.select>` to raise :exc:`select.error` instead of :exc:`IOError`.
- Fixed setup.py to proceed with compilation even if libevent version cannot be determined.
  1.x.x is assumed in this case.
- Fixed compatibility of .pyx files with Cython 0.12.0.
- Renamed arguments for :func:`select.select` to what they are called in the stdlib.
- Removed internal function :func:`getLinkedCompleted` from :mod:`gevent.greenlet`.
- Remove ``#warning`` directives from ``libevent.h``. They are not supported by vc90.
- Removed some deprecated stuff from :mod:`coros`.
- Internal class :class:`Waiter <gevent.hub.Waiter>` now stores the value if no one's waiting for it.
- Added ``testrunner.py`` script that replaces a bunch of small scripts that were used before.
- Removed ``is_secure`` attribute from sockets and ssl objects.
- Made :class:`Greenlet` not to print a traceback when a not-yet-started greenlet is killed.
- Added :class:`BackdoorServer` class to :mod:`backdoor`. Removed :func:`backdoor` function and deprecated :func:`backdoor_server` function.
- Removed ``__getattr__`` from socket class.
- Fixed :func:`monkey.patch_socket` not to fail if :func:`socket.ssl` is not present in :mod:`gevent.socket`.
- Added :func:`monkey.patch_ssl`.
- Added *aggressive* argument to :func:`monkey.patch_all`.
- Tests from stdlib no longer included in greentest package. Instead, there are number of stubs
  that import those tests from ``test`` package directly and run them in monkey patched environment.
- Added examples/process.py by **Marcus Cavanaugh**.


Release 0.11.2 (Dec 10, 2009)
=============================

* Fixed :mod:`wsgi` to unquote ``environ['PATH_INFO']`` before passing to application.
* Added ``SERVER_SOFTWARE`` variable to :mod:`wsgi` environ.
* Fixed bug in :meth:`JoinableQueue.task_done` that caused :class:`ValueError` to be raised incorrectly here.
* Fixed :mod:`gevent.socket` not to fail with :class:`ImportError` if Python was not built with ssl support.


Release 0.11.1 (Nov 15, 2009)
=============================

* Fixed bug in :func:`select.select` function. Passing non-empty list of write descriptors used to cause this function to fail.
* Changed setup.py to go ahead with the compilation even if the actual version of libevent cannot be determined (version 1.x.x is assumed in that case).

Contributed by **Ludvig Ericson**:

* Fixed :mod:`wsgi`'s ``start_response`` to recognize *exc_info* argument.
* Fixed setup.py to look for libevent.dylib rather than .so on Darwin platforms.


Release 0.11.0 (Oct 9, 2009)
============================

* Fixed timeout bug in :func:`joinall`, :meth:`Greenlet.join`, :meth:`pool.Pool.join`: if timeout has expired
  it used to raise :class:`Timeout`; now it returns silently.
* Fixed :func:`signal` to run the signal handler in a new greenlet; it was run in the :class:`Hub` greenlet before.
* Fixed :meth:`Timeout.start_new`: if passed a :class:`Timeout` instance, it now calls its :meth:`start <Timeout.start>`
  method before returning it.
* Fixed :mod:`gevent.monkey` to patch :class:`threading.local` properly.
* Fixed :meth:`Queue.empty` and :meth:`Queue.full` to be compatible
  with the standard :mod:`Queue`. It tried to take into account the greenlets currently blocking on
  :meth:`get <Queue.get>`/:meth:`put <Queue.put>` which
  was not useful and hard to reason about. Now it simply compares :meth:`qsize <Queue.qsize>` to *maxsize*,
  which what the standard :mod:`Queue` does too.
* Fixed :class:`Event` to behave exactly like the standard :class:`threading.Event`:

  - :meth:`Event.set` does not accept a parameter anymore; it's now either set or not.
  - ``Event.get`` method is gone.
  - ``Event.set(); Event.clear()`` used to be a no-op; now it properly wakes up all the waiters.
  - :class:`AsyncResult` behaves exactly like before, but it does not inherit from :class:`Event` anymore
    and does miss ``clear()`` method.

* Renamed internal helpers :meth:`socket.wait_reader`/:meth:`socket.wait_writer` to :meth:`socket.wait_read`/:meth:`socket.wait_write`.
* Renamed :class:`gevent.socket.GreenSocket` to :class:`gevent.socket.socket`. ``GreenSocket`` is still available
  as an alias but will be removed in the future.
* :mod:`gevent.core` now includes wrappers for evbuffer, evdns, evhttp.
* Renamed the old ``gevent.wsgi`` to :mod:`gevent.pywsgi`.
* Added a new HTTP server :mod:`gevent.http` module based on libevent-http wrappers.
* Added a new WSGI server :mod:`gevent.wsgi` module based on :mod:`gevent.http`.
* Added evdns wrappers to :mod:`gevent.core` and DNS functions to :mod:`gevent.socket` module. Contributed by **Jason Toffaletti.**.
* Added a few a few options to ``setup.py`` to select a libevent library to compile against. Check them out with ``setup.py -h``.
* Added ``__all__`` to many modules that missed it.
* Converted the docstrings and the changelog to sphinx/rst markup.
* Added sphinx/rst documentation. It is available online at http://www.gevent.org.


Release 0.10.0 (Aug 26, 2009)
=============================

* Changed :class:`Timeout` API in a backward-incompatible way:
  :meth:`Timeout.__init__` does not start the timer immediately anymore;
  :meth:`Timeout.start` must be called explicitly.
  A shortcut - :meth:`Timeout.start_new` - is provided that creates and starts
  a :class:`Timeout`.
* Added :class:`gevent.Greenlet` class which is a subclass of greenlet that adds a few
  useful methods :meth:`join <Greenlet.join>`/:meth:`get <Greenlet.get>`/:meth:`kill <Greenlet.kill>`/:meth:`link <Greenlet.link>`.
* :func:`spawn` now returns :class:`Greenlet` instance. The old ``spawn``, which returns ``py.magic.greenlet``
  instance, can be still accessed as :meth:`spawn_raw`.

  .. note::

     The implementation of :class:`Greenlet` is an improvement on ``proc`` module, with these bugs fixed:

     * Proc was not a subclass of greenlet which makes :func:`getcurrent` useless and using
       Procs as keys in dict impossible.
     * Proc executes links sequentially, so one could block the rest from being
       executed. :class:`Greenlet` executes each link in a new greenlet by default, unless
       it is set up with :class:`Greenlet.rawlink` method.
     * Proc cannot be easily subclassed. To subclass :class:`Greenlet`, override its _run
       and __init__ methods.

* Added :class:`pool.Pool` class with the methods compatible to the standard :mod:`multiprocessing.pool`:
  :meth:`apply <Pool.apply>`, :meth:`map <Pool.map>` and others.
  It also has :meth:`spawn <Pool.spawn>` method which is always async and returns a
  :class:`Greenlet` instance.
* Added :mod:`gevent.event` module with 2 classes: :class:`Event` and :class:`AsyncResult`.
  :class:`Event` is a drop-in replacement for :class:`threading.Event`, supporting
  :meth:`set <Event.set>`/:meth:`wait <Event.wait>`/``get`` methods. :class:`AsyncResult`
  is an extension of :class:`Event` that supports exception passing via :meth:`set_exception <AsyncResult.set_exception>` method.
* Added :class:`queue.JoinableQueue` class with :meth:`task_done <queue.JoinableQueue.task_done>`
  and :meth:`join <queue.JoinableQueue.join>` methods.
* Renamed ``core.read`` and ``core.write`` classes to :class:`core.read_event` and :class:`core.write_event`.
* :mod:`gevent.pywsgi`: pulled **Mike Barton's** eventlet patches that fix double content-length issue.
* Fixed ``setup.py`` to search more places for system libevent installation.
  This fixes 64bit CentOS 5.3 installation issues, hopefully covers other platforms
  as well.

The following items were added to the gevent top level package:

- :func:`spawn_link`
- :func:`spawn_link_value`
- :func:`spawn_link_exception`
- :func:`spawn_raw`
- :func:`joinall`
- :func:`killall`
- :class:`Greenlet`
- :exc:`GreenletExit`
- :mod:`core`

The following items were marked as deprecated:

- gevent.proc module (:class:`wrap_errors` helper was moved to :mod:`util` module)
- gevent.coros.event
- gevent.coros.Queue and gevent.coros.Channel

Internally, ``gevent.greenlet`` was split into a number of modules:

- :mod:`gevent.hub` provides :class:`Hub` class and basic utilities, like :func:`sleep`;
  :class:`Hub` is now a subclass of greenlet.
- :mod:`gevent.timeout` provides :class:`Timeout` and :func:`with_timeout`;
- :mod:`gevent.greenlet` provides :class:`Greenlet` class and helpers like :func:`joinall` and :func:`killall`.
- :mod:`gevent.rawgreenlet` contains the old "polling" versions of
  :func:`joinall <rawgreenlet.joinall>` and :func:`killall <rawgreenlet.killall>` (they do not need :meth:`link <Greenlet.link>`
  functionality and work with any greenlet by polling their status and sleeping in a loop)


Thanks to **Jason Toffaletti** for reporting the installation issue and providing a
test case for WSGI double content-length header bug.


Release 0.9.3 (Aug 3, 2009)
===========================

* Fixed all known bugs in the :mod:`gevent.queue` module and made it 2.4-compatible.
  :class:`LifoQueue` and :class:`PriorityQueue` are implemented as well.
  :mod:`gevent.queue` will deprecate both ``coros.Queue`` and ``coros.Channel``.
* Fixed :class:`Timeout` to raise itself by default. ``TimeoutError`` is gone.
  Silent timeout is now created by passing ``False`` instead of ``None``.
* Fixed bug in :func:`gevent.select.select` where it could silent the wrong timeout.
* :func:`spawn` and :func:`spawn_later` now avoid creating a closure and this decreases spawning
  time by 50%.
* ``kill``'s and ``killall``'s *wait* argument was renamed to *block*. The polling is now
  implemented by ``greenlet.join`` and ``greenlet.joinall`` functions and it become more
  responsive, with gradual increase of sleep time.
* Renamed ``proc.RunningProcSet`` to ``proc.ProcSet``.
* Added :func:`shutdown` function, which blocks until libevent has finished dispatching the events.
* The return value of ``event_add`` and ``event_del`` in core.pyx are now checked properly
  and :exc:`IOError` is raised if they have failed.
* Fixed backdoor.py, accidentally broken in the previous release.


Release 0.9.2 (Jul 20, 2009)
============================

* Simplified :mod:`gevent.socket`'s implementation and fixed SSL bug reported on eventletdev
  by **Cesar Alaniz** as well as failures in ``test_socket_ssl.py``.
* Removed ``GreenSocket.makeGreenFile``; Use :meth:`socket.socket.makefile` that returns :class:`_fileobject`
  and is available on both :class:`GreenSocket <gevent.socket.socket>` and :class:`GreenSSL <gevent.socket.GreenSSL>`.
  The :mod:`gevent.socket` is still a work in progress.
* Added new :class:`core.active_event` class that takes advantage of libevent's ``event_active`` function.
  ``core.active_event(func)`` schedules func to be run in this event loop iteration as opposed
  to ``core.timer(0, ...)`` which schedules an event to be run in the next iteration.
  :class:`active_event` is now used throughout the library wherever ``core.timer(0, ....)`` was previously used.
  This results in :func:`spawn` being at least 20% faster compared to release 0.9.1 and twice as fast compared to
  eventlet. (The results are obtained with bench_spawn.py script in ``greentest/`` directory)
* Added boolean parameter *wait* to :func:`kill` and :func:`killall` functions. If set to ``True``, it makes the
  function block until the greenlet(s) is actually dead. By default, :func:`kill` and :func:`killall` are asynchronous,
  i.e. they don't unschedule the current greenlet.
* Added a few new properties to :class:`gevent.core.event`: :attr:`fd <event.fd>`, :attr:`events <event.events>`,
  :attr:`events_str <event.events_str>` and :attr:`flags <event.flags>`. It also has :meth:`__enter__ <event.__enter__>`
  and :meth:`__exit__ <event.__exit__>` now, so it can be used as a context
  manager. :class:`event`'s :attr:`callback <event.callback>` signature has changed from ``(event, fd, evtype)`` to ``(event, evtype)``.
* Fixed :class:`Hub`'s mainloop to never return successfully as this will screw up main greenlet's ``switch()`` call.
  Instead of returning it raises ``DispatchExit``.
* Added :func:`reinit` function - wrapper for libevent's ``event_reinit``.
  This function is a must have at least for daemons, as it fixes ``epoll`` and some others eventloops to work after ``fork``.
* Trying to use gevent in another thread will now raise an exception immediately, since it's not implemented.
* Added a few more convenience methods ``spawn_link[exception/value]`` to ``proc.RunningProcSet``.
* Fixed ``setup.py`` not to depend on ``setuptools``.
* Removed ``gevent.timeout``. Use :class:`gevent.Timeout`.


Release 0.9.1 (Jul 9, 2009)
===========================

* Fixed compilation with libevent-1.3. Thanks to **Litao Wei** for reporting the problem.
* Fixed :class:`Hub` to recover silently after ``event_dispatch()`` failures (I've seen this
  happen after ``fork`` even though ``event_reinit()`` is called as necessary). The end result is that :func:`fork`
  now works more reliably, as detected by ``test_socketserver.py`` - it used to fail occasionally, now it does not.
* Reorganized the package, most of the stuff from ``gevent/__init__.py`` was moved to ``gevent/greenlet.py``.
  ``gevent/__init__.py`` imports some of it back but not everything.
* Renamed ``gevent.timeout`` to :class:`gevent.Timeout`. The old name is available as an alias.
* Fixed a few bugs in :class:`queue.Queue`.
  Added test_queue.py from standard tests to check how good is :class:`queue.Queue` a replacement
  for a standard :mod:`Queue` (not good at all, timeouts in :meth:`queue.Queue.put` don't work yet)
* :mod:`monkey` now patches ssl module when on 2.6 (very limited support).
* Improved compatibility with Python 2.6 and Python 2.4.
* Greenlet installed from PyPI (without py.magic prefix) is properly recognized now.
* core.pyx was accidentally left out of the source package, it's included now.
* :class:`GreenSocket <socket.socket>` now wraps a ``socket`` object from ``_socket`` module rather
  than from :mod:`socket`.


Release 0.9.0 (Jul 8, 2009)
===========================

Started as eventlet_ 0.8.11 fork, with the intention to support only libevent as a backend.
Compared to eventlet, this version has a much simpler API and implementation and a few
severe bugs fixed, namely

* Full duplex in sockets, i.e. ``read()`` and ``write()`` on the same fd do not cancel one another.
* The :meth:`GreenSocket.close <socket.socket.close>` method does not hang as it could with eventlet.

There's a test in my repo of eventlet that reproduces both of them:
http://bitbucket.org/denis/eventlet/src/tip/greentest/test__socket.py

Besides having less bugs and less code to care about the goals of the fork are:

* Piggy-back on libevent as much as possible (use its http and dns code).
* Use the interfaces and conventions from the standard Python library where possible.

.. _eventlet: http://bitbucket.org/denis/eventlet

..

   Local Variables:
   flycheck-mode: nil
   End:
